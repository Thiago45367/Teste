#pip install -r requirements.txt

# Main.py
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager
from kivy.properties import DictProperty, StringProperty

from app.Backend.Controle.ControleUs import ControleUsu
from app.Backend.Controle.ControleEmp import ControleEmp

# importa suas telas
from app.Frontend.TelaLogin import TelaLogin
from app.Frontend.TelaCadastroUsuario import TelaCadastroUs
from app.Frontend.TelaCadastroEmpresa import TelaCadastroEmp

from app.Frontend.InterfaceUsuario.TelaInicioUs import TelaInicialUsuario
from app.Frontend.InterfaceUsuario.TelaMapaUs import TelaMapaUsuario

from app.Frontend.InterfaceEmpr.TelaInicioEmp import TelaInicialEmpresa
from app.Frontend.InterfaceEmpr.TelaMapaEmp import TelaMapaEmpresa
from app.Frontend.InterfaceEmpr.TelaNotificacaoEmp import TelaNotificacoesEmp

class GerenciadorTelas(ScreenManager):
    pass

# --- Customização do downloader do MapView ---
from kivy_garden import mapview
from kivy_garden.mapview.downloader import Downloader
import requests
from kivy.app import App

class CustomDownloader(Downloader):
    def _load_tile(self, *args, **kwargs):
        try:
            return super()._load_tile(*args, **kwargs)
        except Exception:
            app = App.get_running_app()
            tela_atual = app.root.current_screen
            if hasattr(tela_atual, "mostrar_popup_erro"):
                tela_atual.mostrar_popup_erro(
                    "⚠️ Não foi possível carregar o mapa.\nVerifique sua conexão com a internet."
                )
            return None

# substituir o downloader padrão
mapview.downloader = CustomDownloader()


class MeuApp(App):
    usuario_nome = StringProperty("")  # precisa ser StringProperty
    usuario_foto = StringProperty("app/Frontend/Assets/Foto_Perfil.png")
    usuario_logado = DictProperty({})

    empresa_nome = StringProperty("")  # precisa ser StringProperty
    empresa_foto = StringProperty("app/Frontend/Assets/Foto_Perfil.png")
    empresa_logado = DictProperty({})

    def build(self):
        sm = GerenciadorTelas()
        sm.add_widget(TelaLogin(name="TelaLogin"))
        sm.add_widget(TelaCadastroUs(name="TelaCadastroUsuario"))
        sm.add_widget(TelaCadastroEmp(name="TelaCadastroEmpresa"))

        sm.add_widget(TelaInicialUsuario(name="TelaInicioUs"))
        sm.add_widget(TelaMapaUsuario(name="TelaMapaUs"))

        sm.add_widget(TelaInicialEmpresa(name="TelaInicioEmp"))
        sm.add_widget(TelaMapaEmpresa(name="TelaMapaEmp"))
        sm.add_widget(TelaNotificacoesEmp(name="TelaNotificacaoEmp"))
        return sm

    def set_usuario_logado(self, email):
        controle = ControleUsu()
        usuario = controle.buscar_usuario_por_email(email)

        if usuario:
            self.usuario_logado = usuario

            # tenta várias chaves possíveis
            if "nome_Usuario" in usuario:
                self.usuario_nome = usuario["nome_Usuario"]
            elif "nome" in usuario:
                self.usuario_nome = usuario["nome"]
            elif "nome_usuario" in usuario:
                self.usuario_nome = usuario["nome_usuario"]
            else:
                self.usuario_nome = "Usuário"

            # foto
            self.usuario_foto = usuario.get("foto", "app/Frontend/Assets/Foto_Perfil.png")
        else:
            self.usuario_logado = {}
            self.usuario_nome = "Usuário"
            self.usuario_foto = "app/Frontend/Assets/Foto_Perfil.png"

    def set_empresa_logado(self, email):
        controle = ControleEmp()
        empresa = controle.buscar_empresa_por_email(email)

        if empresa:
            self.empresa_logado = empresa

            # tenta várias chaves possíveis
            if "nome_Empresa" in empresa:
                self.empresa_nome = empresa["nome_Empresa"]
            elif "nome" in empresa:
                self.empresa_nome = empresa["nome"]
            elif "nome_empresa" in empresa:
                self.empresa_nome = empresa["nome_empresa"]
            else:
                self.empresa_nome = "Usuário"

            # foto
            self.empresa_foto = empresa.get("foto", "app/Frontend/Assets/Foto_Perfil.png")
        else:
            self.empresa_logado = {}
            self.empresa_nome = "Usuário"
            self.empresa_foto = "app/Frontend/Assets/Foto_Perfil.png"


if __name__ == "__main__":
    # 🔹 Teste: criar postagem antes de abrir o app
    from app.Backend.Controle.ControlePostagemEmp import ControlePostagemEmp
    controle = ControlePostagemEmp()
    resultado = controle.criar_postagem("🚀 Teste de postagem automática da empresa!")
    print("🧩 Resultado da criação de postagem:", resultado)

    MeuApp().run()