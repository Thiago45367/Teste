from app.Backend.Modelo.ModeloEmpresa import ModeloEmpresa
from app.Backend.Modelo.ModeloPonto_Coleta import ModeloPontoColeta
from app.Backend.Dao.DaoEmp import DaoEmp
from app.Backend.Dao.DaoEmpPontoColeta import DaoEmpPontoColeta
from app.Backend.Controle.ControleLogin import ControleLogin

import requests

from app.Backend.Dao.DaoEmp import DaoEmp
from app.Backend.Dao.DaoEmpPontoColeta import DaoEmpPontoColeta
from app.Backend.Modelo.ModeloEmpresa import ModeloEmpresa
from app.Backend.Controle.ControleLogin import ControleLogin


class ControleEmp:
    def __init__(self):
        self.dao_emp = DaoEmp()
        self.dao_ponto = DaoEmpPontoColeta()

    # ---------------- EMPRESA ----------------
    def cadastrar_empresa(self, cnpj, nome_Empresa, email_Empresa, senha_Empresa, telefone_Empresa):
        """
        Cadastra empresa e cria automaticamente o login vinculado.
        """
        print(f"🟡 [DEBUG] Iniciando cadastro da empresa {nome_Empresa} ({email_Empresa})")

        empresa = ModeloEmpresa(
            cnpj=cnpj,
            nome_Empresa=nome_Empresa,
            telefone_Empresa=telefone_Empresa
        )

        resultado = self.dao_emp.cadastrar_empresa_com_login(empresa, email_Empresa, senha_Empresa)

        if resultado.get("sucesso"):
            print("✅ Empresa cadastrada com sucesso. Buscando dados completos...")

            empresa_info = self.dao_emp.buscar_empresa_por_email(email_Empresa)
            if empresa_info.get("sucesso"):
                ControleLogin.usuario_logado = {
                    "id": empresa_info["dados"]["id_Empresa"],
                    "nome": empresa_info["dados"]["nome_Empresa"],
                    "email": empresa_info["dados"]["email_Empresa"],
                    "tipo": "empresa"
                }
                print(f"✅ Empresa logada automaticamente: {ControleLogin.usuario_logado}")
            else:
                print("⚠️ Não foi possível buscar os dados da empresa após cadastro.")
        else:
            print(f"❌ Falha no cadastro: {resultado.get('mensagem', 'Erro desconhecido.')}")

        return resultado

    def buscar_empresa_por_email(self, email_Empresa):
        return self.dao_emp.buscar_empresa_por_email(email_Empresa)

    def existe_email_empresa(self, email_Empresa):
        return self.dao_emp.existe_email(email_Empresa)

    def existe_cnpj(self, cnpj):
        return self.dao_emp.existe_cnpj(cnpj)

    # ---------------- PONTO DE COLETA ----------------
    def buscar_lat_lon_por_cep(self, cep: str):
        try:
            print(f"📍 [DEBUG] Buscando endereço e coordenadas para CEP {cep}")
            headers = {"User-Agent": "RecyTechApp/1.0"}

            via = requests.get(f"https://viacep.com.br/ws/{cep}/json/", timeout=5)
            via.raise_for_status()
            dados = via.json()

            if "erro" in dados:
                print("⚠️ [DEBUG] CEP não encontrado no ViaCEP, aplicando fallback manual...")
                endereco_str = f"{cep}, Bonfim, Salvador, Bahia, Brasil"
            else:
                logradouro = dados.get("logradouro", "")
                bairro = dados.get("bairro", "")
                localidade = dados.get("localidade", "")
                uf = dados.get("uf", "")
                endereco_str = f"{logradouro}, {bairro}, {localidade}, {uf}, Brasil"

            print(f"🌍 [DEBUG] Consultando Nominatim para: {endereco_str}")

            resp = requests.get(
                "https://nominatim.openstreetmap.org/search",
                params={"q": endereco_str, "format": "json", "limit": 3},
                headers=headers,
                timeout=8
            )
            resp.raise_for_status()
            resultados = resp.json()

            if isinstance(resultados, list) and resultados:
                lat = float(resultados[0]["lat"])
                lon = float(resultados[0]["lon"])
                print(f"✅ [DEBUG] Coordenadas encontradas: ({lat}, {lon})")
                return {"sucesso": True, "lat": lat, "lon": lon}

            print("❌ [DEBUG] Falha ao obter coordenadas: Endereço não encontrado.")
            return {"sucesso": False, "mensagem": "Endereço não encontrado."}

        except Exception as e:
            print(f"❌ [ERRO] buscar_lat_lon_por_cep: {e}")
            return {"sucesso": False, "mensagem": f"Erro inesperado: {e}"}

    def cadastrar_ponto(self, nome, cep, numero_Endereco_Ponto, horario, tipo_Coleta, remuneracao):
        """Cadastra ponto de coleta vinculado à empresa logada.
           IMPORTANT: número é armazenado mas NÃO é usado para geocoding (só CEP).
        """
        try:
            if not ControleLogin.usuario_logado or ControleLogin.usuario_logado["tipo"] != "empresa":
                return {"sucesso": False, "mensagem": "Nenhuma empresa logada."}

            id_empresa = ControleLogin.usuario_logado["id"]
            print(f"🟡 [DEBUG] Empresa logada: ID {id_empresa}")

            # buscar coordenadas usando apenas CEP (vários fallback internos)
            resultado = self.buscar_lat_lon_por_cep(cep)
            if not resultado["sucesso"]:
                print(f"❌ [DEBUG] Falha ao obter coordenadas: {resultado['mensagem']}")
                return {"sucesso": False, "mensagem": resultado["mensagem"]}

            ponto = ModeloPontoColeta(
                nome_Ponto=nome,
                cep=cep,
                numero_Endereco_Ponto=numero_Endereco_Ponto,
                horario=horario,
                tipo_Coleta=tipo_Coleta,
                remuneracao=remuneracao,
                latitude=resultado["lat"],
                longitude=resultado["lon"],
                fk_Empresa=id_empresa
            )

            print(f"🟢 [DEBUG] Tentando cadastrar ponto: {ponto.__dict__}")
            resposta = self.dao_ponto.cadastrar_ponto(ponto)
            print(f"✅ [DEBUG] Resultado do DAO: {resposta}")
            return resposta

        except Exception as e:
            print(f"❌ [ERRO] cadastrar_ponto: {e}")
            return {"sucesso": False, "mensagem": f"Erro inesperado: {e}"}

    def listar_pontos(self, id_empresa=None):
        try:
            if id_empresa is None:
                if not ControleLogin.usuario_logado or ControleLogin.usuario_logado["tipo"] != "empresa":
                    return {"sucesso": False, "mensagem": "Nenhuma empresa logada.", "dados": []}
                id_empresa = ControleLogin.usuario_logado["id"]

            print(f"🟡 [DEBUG] Listando pontos da empresa ID {id_empresa}")
            resposta = self.dao_ponto.listar_pontos(id_empresa=id_empresa)

            if isinstance(resposta, dict):
                if "dados" not in resposta:
                    resposta["dados"] = []
                return resposta
            else:
                return {"sucesso": False, "mensagem": "Formato de retorno inválido.", "dados": []}

        except Exception as e:
            print(f"❌ [ERRO] listar_pontos: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao listar pontos: {e}", "dados": []}