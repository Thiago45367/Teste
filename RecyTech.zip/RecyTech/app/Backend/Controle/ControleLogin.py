class ControleLogin:
    usuario_logado = None

    def __init__(self, dao_login):
        self.dao_login = dao_login

    def login(self, email, senha):
        usuario = self.dao_login.verificar_login(email, senha)  # 👈 muda aqui
        if usuario:
            ControleLogin.usuario_logado = usuario
            print(f"✅ Usuário logado: {ControleLogin.usuario_logado}")
            return usuario
        else:
            ControleLogin.usuario_logado = None
            print("❌ Login inválido.")
            return None