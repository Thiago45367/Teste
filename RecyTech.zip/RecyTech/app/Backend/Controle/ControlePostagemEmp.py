from app.Backend.Dao.DaoPostagemEmp import DaoPostagemEmp
from app.Backend.Controle.ControleLogin import ControleLogin
from app.Backend.Modelo.ModeloPostagens import ModeloPostagens
from datetime import datetime

class ControlePostagemEmp:
    def __init__(self):
        self.dao_postagem = DaoPostagemEmp()

    # -------------------------------------------------------------------
    # 🔹 Criar nova postagem
    # -------------------------------------------------------------------
    def criar_postagem(self, conteudo_Post):
        """
        Cria uma nova postagem feita pela empresa logada.
        """
        try:
            if not ControleLogin.usuario_logado or ControleLogin.usuario_logado["tipo"] != "empresa":
                return {"sucesso": False, "mensagem": "Nenhuma empresa logada."}

            id_empresa = ControleLogin.usuario_logado["id"]

            if not conteudo_Post.strip():
                return {"sucesso": False, "mensagem": "O conteúdo da postagem não pode estar vazio."}

            postagem = ModeloPostagens(
                id_Post=None,
                id_Usuario=None,
                conteudo_Post=conteudo_Post.strip(),
                data_Post=datetime.now(),
                tipo="empresa",
                fk_Empresa=id_empresa
            )

            resultado = self.dao_postagem.criar_post(
                conteudo_post=postagem.conteudo_Post,
                tipo="empresa",
                fk_empresa=id_empresa
            )

            if resultado.get("sucesso"):
                print(f"✅ [DEBUG] Postagem criada pela empresa ID {id_empresa}")
            else:
                print(f"❌ [DEBUG] Falha ao criar postagem: {resultado.get('mensagem')}")

            return resultado

        except Exception as e:
            print(f"❌ [ERRO] criar_postagem: {e}")
            return {"sucesso": False, "mensagem": f"Erro inesperado: {e}"}

    # -------------------------------------------------------------------
    # 🔹 Listar todas as postagens (feed)
    # -------------------------------------------------------------------
    def listar_postagens(self, limit=20, offset=0):
        """
        Lista todas as postagens do feed geral (reciclagem e lixo eletrônico).
        """
        try:
            resultado = self.dao_postagem.listar_posts(limit, offset)
            if resultado.get("sucesso"):
                print(f"🟢 [DEBUG] {len(resultado['dados'])} postagens encontradas no feed.")
            else:
                print("⚠️ [DEBUG] Nenhuma postagem encontrada.")
            return resultado
        except Exception as e:
            print(f"❌ [ERRO] listar_postagens: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao listar postagens: {e}", "dados": []}

    # -------------------------------------------------------------------
    # 🔹 Listar postagens por empresa específica
    # -------------------------------------------------------------------
    def listar_postagens_empresa(self, id_empresa=None):
        """
        Lista postagens de uma empresa específica (por padrão, da logada).
        """
        try:
            if id_empresa is None:
                if not ControleLogin.usuario_logado or ControleLogin.usuario_logado["tipo"] != "empresa":
                    return {"sucesso": False, "mensagem": "Nenhuma empresa logada.", "dados": []}
                id_empresa = ControleLogin.usuario_logado["id"]

            resultado = self.dao_postagem.listar_posts_por_empresa(id_empresa)

            if resultado.get("sucesso"):
                print(f"🟢 [DEBUG] {len(resultado['dados'])} postagens encontradas para empresa {id_empresa}.")
            else:
                print(f"⚠️ [DEBUG] Nenhuma postagem encontrada para empresa {id_empresa}.")
            return resultado
        except Exception as e:
            print(f"❌ [ERRO] listar_postagens_empresa: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao listar postagens: {e}", "dados": []}