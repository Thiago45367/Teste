# ControleUsuario.py
from app.Backend.Modelo.ModeloUsuario import ModeloUsuario
from app.Backend.Dao.DaoUs import DaoUs

class ControleUsu:
    def __init__(self):
        self.dao = DaoUs()

    def cadastrar_usuario(self, email_Usuario, senha_Usuario, nome_Usuario, data_nascimento):
        """🔹 Cadastra usuário e retorna dict com dados do usuário ou None"""
        usuario = ModeloUsuario(
            email_Usuario=email_Usuario,
            senha_Usuario=senha_Usuario,
            nome_Usuario=nome_Usuario,
            data_nascimento=data_nascimento
        )

        return self.dao.cadastrar_usuario(usuario)

    def buscar_usuario_por_email(self, email_Usuario):
        """🔹 Buscar usuário (dict) pelo email"""
        return self.dao.buscar_usuario_por_email(email_Usuario)