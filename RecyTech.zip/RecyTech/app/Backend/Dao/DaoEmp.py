import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao


class DaoEmp:
    def __init__(self):
        pass  # cada método abre e fecha sua própria conexão

    # -------------------------------------------------------
    # 🔹 Cadastrar empresa + login
    # -------------------------------------------------------
    def cadastrar_empresa_com_login(self, empresa, email, senha):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor()
        try:
            # --- validações antes do cadastro ---
            if self.existe_cnpj(empresa.cnpj):
                print(f"⚠️ [DEBUG] CNPJ '{empresa.cnpj}' já cadastrado.")
                return {"sucesso": False, "mensagem": "CNPJ já cadastrado."}

            if self.existe_email(email):
                print(f"⚠️ [DEBUG] Email '{email}' já cadastrado.")
                return {"sucesso": False, "mensagem": "Email já cadastrado."}

            # 1️⃣ Inserir primeiro na tabela Login
            sql_login = """
                INSERT INTO Login (email_Login, senha_Login, tipo)
                VALUES (%s, %s, %s)
            """
            valores_login = (email, senha, "empresa")
            cursor.execute(sql_login, valores_login)
            id_login = cursor.lastrowid  # pega o id do login criado

            # 2️⃣ Inserir na tabela Empresa, vinculando ao Login
            sql_empresa = """
                INSERT INTO Empresa (cnpj, nome_Empresa, telefone_Empresa, fk_Login)
                VALUES (%s, %s, %s, %s)
            """
            valores_empresa = (
                empresa.cnpj,
                empresa.nome_Empresa,
                empresa.telefone_Empresa,
                id_login
            )
            cursor.execute(sql_empresa, valores_empresa)
            conexao.commit()

            print(f"✅ [DEBUG] Empresa '{empresa.nome_Empresa}' cadastrada com sucesso. ID Login: {id_login}")
            return {"sucesso": True, "mensagem": "Empresa cadastrada com sucesso.", "id_login": id_login}

        except mysql.connector.Error as erro:
            conexao.rollback()
            print(f"❌ [DEBUG] Erro MySQL: {erro}")
            return {"sucesso": False, "mensagem": f"Erro ao cadastrar empresa: {erro}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------------------------------------
    # 🔹 Verifica se email já existe no Login
    # -------------------------------------------------------
    def existe_email(self, email):
        conexao = criar_conexao()
        if not conexao:
            return False

        cursor = conexao.cursor()
        try:
            sql = "SELECT id_Login FROM Login WHERE email_Login = %s"
            cursor.execute(sql, (email,))
            resultado = cursor.fetchone()

            existe = resultado is not None
            print(f"🧩 [DEBUG] Verificação de email '{email}': {'existe' if existe else 'não existe'}")
            return existe

        except mysql.connector.Error as e:
            print(f"❌ Erro ao verificar email: {e}")
            return False
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------------------------------------
    # 🔹 Verifica se CNPJ já existe na Empresa
    # -------------------------------------------------------
    def existe_cnpj(self, cnpj):
        conexao = criar_conexao()
        if not conexao:
            return False

        cursor = conexao.cursor()
        try:
            sql = "SELECT id_Empresa FROM Empresa WHERE cnpj = %s"
            cursor.execute(sql, (cnpj,))
            resultado = cursor.fetchone()

            existe = resultado is not None
            print(f"🧩 [DEBUG] Verificação de CNPJ '{cnpj}': {'existe' if existe else 'não existe'}")
            return existe

        except mysql.connector.Error as e:
            print(f"❌ Erro ao verificar CNPJ: {e}")
            return False
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------------------------------------
    # 🔹 Buscar empresa pelo email do login
    # -------------------------------------------------------
    def buscar_empresa_por_email(self, email):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor(dictionary=True)
        sql = """
            SELECT e.id_Empresa, e.nome_Empresa, e.telefone_Empresa, l.email_Login
            FROM Empresa e
            JOIN Login l ON e.fk_Login = l.id_Login
            WHERE l.email_Login = %s
        """
        cursor.execute(sql, (email,))
        empresa = cursor.fetchone()

        cursor.close()
        fechar_conexao(conexao)

        if empresa:
            print(f"✅ [DEBUG] Empresa encontrada: {empresa['nome_Empresa']}")
            return {
                "sucesso": True,
                "dados": {
                    "id_Empresa": empresa["id_Empresa"],
                    "nome_Empresa": empresa["nome_Empresa"],
                    "telefone_Empresa": empresa["telefone_Empresa"],
                    "email_Empresa": empresa["email_Login"],
                    "foto": "app/Frontend/Assets/Foto_Perfil.png"
                }
            }

        print(f"⚠️ [DEBUG] Nenhuma empresa encontrada com email '{email}'")
        return {"sucesso": False, "mensagem": "Empresa não encontrada."}