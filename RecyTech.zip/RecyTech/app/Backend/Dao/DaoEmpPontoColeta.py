import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao
from app.Backend.Modelo.ModeloPonto_Coleta import ModeloPontoColeta

class DaoEmpPontoColeta:
    def cadastrar_ponto(self, ponto: ModeloPontoColeta):
        conexao = criar_conexao()
        if not conexao:
            print("❌ [DEBUG] Falha ao criar conexão com o banco de dados.")
            return {"sucesso": False, "mensagem": "Sem conexão com o banco."}

        cursor = conexao.cursor(dictionary=True)
        try:
            print("🚀 [DEBUG] Entrou em cadastrar_ponto()")
            print("🔹 [DEBUG] Dados recebidos do modelo:")
            print("    Nome:", ponto.nome_Ponto)
            print("    CEP:", ponto.cep)
            print("    Número:", getattr(ponto, "numero_Endereco_Ponto", None))
            print("    Horário:", ponto.horario)
            print("    Tipo de Coleta:", ponto.tipo_Coleta)
            print("    Remuneração:", ponto.remuneracao)
            print("    Latitude:", ponto.latitude)
            print("    Longitude:", ponto.longitude)
            print("    FK_Empresa:", ponto.fk_Empresa)

            sql = """
                INSERT INTO ponto_coleta 
                (nome_Ponto, cep, numero_Endereco_Ponto, horario, tipo_Coleta, remuneracao, latitude, longitude, fk_Empresa)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            valores = (
                ponto.nome_Ponto,
                ponto.cep,
                getattr(ponto, "numero_Endereco_Ponto", ""),
                ponto.horario,
                ponto.tipo_Coleta,
                ponto.remuneracao,
                ponto.latitude,
                ponto.longitude,
                ponto.fk_Empresa
            )

            cursor.execute(sql, valores)
            conexao.commit()

            id_ponto = cursor.lastrowid
            print(f"✅ [DEBUG] Inserção bem-sucedida! Novo ID do ponto: {id_ponto}")

            return {
                "sucesso": True,
                "mensagem": f"Ponto cadastrado com sucesso! ID: {id_ponto}",
                "dados": {"id_ponto": id_ponto}
            }

        except mysql.connector.Error as e:
            conexao.rollback()
            print("❌ [ERRO SQL] Falha ao inserir ponto de coleta:", e)
            return {"sucesso": False, "mensagem": f"Erro ao cadastrar ponto: {e}"}

        except Exception as ex:
            conexao.rollback()
            print("💥 [ERRO GERAL] Ocorreu um erro inesperado:", ex)
            return {"sucesso": False, "mensagem": f"Erro inesperado: {ex}"}

        finally:
            cursor.close()
            fechar_conexao(conexao)
            print("🔒 [DEBUG] Conexão com o banco encerrada.\n")

    def listar_pontos(self, id_empresa=None):
        conexao = criar_conexao()
        if not conexao:
            print("❌ [DEBUG] Falha ao criar conexão com o banco para listagem.")
            return {"sucesso": False, "mensagem": "Sem conexão com o banco."}

        cursor = conexao.cursor(dictionary=True)
        try:
            if id_empresa:
                print(f"🟡 [DEBUG] Listando pontos para empresa ID {id_empresa}")
                cursor.execute("""
                    SELECT id_Ponto_Coleta, nome_Ponto, cep, numero_Endereco_Ponto, horario, 
                           tipo_Coleta, remuneracao, latitude, longitude, fk_Empresa
                    FROM ponto_coleta
                    WHERE fk_Empresa = %s
                """, (id_empresa,))
            else:
                print("🟡 [DEBUG] Listando todos os pontos (sem filtro de empresa)")
                cursor.execute("""
                    SELECT id_Ponto_Coleta, nome_Ponto, cep, numero_Endereco_Ponto, horario, 
                           tipo_Coleta, remuneracao, latitude, longitude, fk_Empresa
                    FROM ponto_coleta
                """)

            resultados = cursor.fetchall()
            print(f"📊 [DEBUG] {len(resultados)} ponto(s) encontrado(s) no banco.")
            return {
                "sucesso": True,
                "mensagem": f"{len(resultados)} ponto(s) encontrado(s).",
                "dados": resultados
            }

        except mysql.connector.Error as e:
            print("❌ [ERRO SQL] Falha ao listar pontos:", e)
            return {"sucesso": False, "mensagem": f"Erro ao listar pontos: {e}"}

        finally:
            cursor.close()
            fechar_conexao(conexao)
            print("🔒 [DEBUG] Conexão encerrada após listagem.\n")