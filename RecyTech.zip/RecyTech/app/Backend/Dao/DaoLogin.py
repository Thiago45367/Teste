# DaoLogin.py
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao

class DaoLogin:
    def __init__(self):
        pass

    def verificar_login(self, email, senha):
        conexao = criar_conexao()
        if not conexao:
            return None
        
        cursor = None
        try:
            cursor = conexao.cursor(dictionary=True)

            # 1️⃣ Buscar se login existe
            query = """
                SELECT id_Login, tipo 
                FROM Login 
                WHERE email_Login = %s AND senha_Login = %s
            """
            cursor.execute(query, (email, senha))
            login = cursor.fetchone()
            print(" Login encontrado:", login)   # <--- DEBUG

            if not login:
                print(" Nenhum login encontrado para esse email/senha")
                return None

            tipo = login["tipo"]
            print(" Tipo:", tipo)   # <--- DEBUG

            # 2️⃣ Buscar dados conforme tipo
            if tipo == "usuario":
                query_usuario = """
                    SELECT id_Usuario AS id, nome_Usuario AS nome
                    FROM Usuario
                    WHERE fk_Login = %s
                """
                cursor.execute(query_usuario, (login["id_Login"],))
                usuario = cursor.fetchone()
                print(" Usuario encontrado:", usuario)   # <--- DEBUG
                if usuario:
                    return {
                        "id": usuario["id"],
                        "nome": usuario["nome"],
                        "tipo": "usuario"
                    }

            elif tipo == "empresa":
                query_empresa = """
                    SELECT id_Empresa AS id, nome_Empresa AS nome
                    FROM Empresa
                    WHERE fk_Login = %s
                """
                cursor.execute(query_empresa, (login["id_Login"],))
                empresa = cursor.fetchone()
                print(" Empresa encontrada:", empresa)   # <--- DEBUG
                if empresa:
                    return {
                        "id": empresa["id"],
                        "nome": empresa["nome"],
                        "tipo": "empresa"
                    }

            return None

        except Exception as e:
            print(f" Erro ao verificar login: {e}")
            return None
        finally:
            if cursor:
                cursor.close()
            fechar_conexao(conexao)
