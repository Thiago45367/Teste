# app/Backend/Dao/DaoPostagem.py
import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao
from datetime import datetime

class DaoPostagem:
    def __init__(self):
        pass

    # -------------------------
    # Criar postagem
    # -------------------------
    def criar_post(self, conteudo_post: str, tipo: str, fk_usuario: int = None, fk_empresa: int = None):
        """
        tipo: 'usuario' ou 'empresa'
        fk_usuario / fk_empresa: id correspondente (um dos dois deve ser preenchido)
        """
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor()
        try:
            sql = """
                INSERT INTO Postagens (conteudo_Post, data_Post, tipo, fk_Usuario, fk_Empresa)
                VALUES (%s, %s, %s, %s, %s)
            """
            agora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            valores = (conteudo_post, agora, tipo, fk_usuario, fk_empresa)
            cursor.execute(sql, valores)
            conexao.commit()
            id_post = cursor.lastrowid
            print(f"✅ [DEBUG] Post criado (id={id_post}) tipo={tipo}")
            return {"sucesso": True, "mensagem": "Post criado com sucesso.", "id_post": id_post}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ [DEBUG] Erro ao criar post: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao criar post: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Buscar post por id
    # -------------------------
    def buscar_post_por_id(self, id_post: int):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario, e.nome_Empresa
                FROM Postagens p
                LEFT JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                LEFT JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                WHERE p.id_Post = %s
            """
            cursor.execute(sql, (id_post,))
            post = cursor.fetchone()
            cursor.close()
            fechar_conexao(conexao)

            if post:
                return {"sucesso": True, "dados": post}
            else:
                return {"sucesso": False, "mensagem": "Post não encontrado."}
        except mysql.connector.Error as e:
            cursor.close()
            fechar_conexao(conexao)
            print(f"❌ Erro buscar_post_por_id: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao buscar post: {e}"}

    # -------------------------
    # Listar posts (feed) - paginado
    # -------------------------
    def listar_posts(self, limit: int = 20, offset: int = 0):
        """
        Retorna posts ordenados por data (mais recentes primeiro).
        limit, offset para paginação.
        """
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario, e.nome_Empresa,
                    (SELECT COUNT(*) FROM Curtidas c WHERE c.fk_Post = p.id_Post) AS curtidas_count,
                    (SELECT COUNT(*) FROM Comentarios cm WHERE cm.fk_Post = p.id_Post) AS comentarios_count
                FROM Postagens p
                LEFT JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                LEFT JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                ORDER BY p.data_Post DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (limit, offset))
            posts = cursor.fetchall()
            return {"sucesso": True, "dados": posts}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_posts: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao listar posts: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Listar posts por empresa
    # -------------------------
    def listar_posts_por_empresa(self, id_empresa: int, limit: int = 20, offset: int = 0):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, e.nome_Empresa,
                    (SELECT COUNT(*) FROM Curtidas c WHERE c.fk_Post = p.id_Post) AS curtidas_count,
                    (SELECT COUNT(*) FROM Comentarios cm WHERE cm.fk_Post = p.id_Post) AS comentarios_count
                FROM Postagens p
                JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                WHERE p.fk_Empresa = %s
                ORDER BY p.data_Post DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (id_empresa, limit, offset))
            posts = cursor.fetchall()
            return {"sucesso": True, "dados": posts}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_posts_por_empresa: {e}")
            return {"sucesso": False, "mensagem": f"Erro: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Listar posts por usuário
    # -------------------------
    def listar_posts_por_usuario(self, id_usuario: int, limit: int = 20, offset: int = 0):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario,
                    (SELECT COUNT(*) FROM Curtidas c WHERE c.fk_Post = p.id_Post) AS curtidas_count,
                    (SELECT COUNT(*) FROM Comentarios cm WHERE cm.fk_Post = p.id_Post) AS comentarios_count
                FROM Postagens p
                JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                WHERE p.fk_Usuario = %s
                ORDER BY p.data_Post DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (id_usuario, limit, offset))
            posts = cursor.fetchall()
            return {"sucesso": True, "dados": posts}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_posts_por_usuario: {e}")
            return {"sucesso": False, "mensagem": f"Erro: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Editar post (apenas conteúdo)
    # -------------------------
    def editar_post(self, id_post: int, novo_conteudo: str):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}
        cursor = conexao.cursor()
        try:
            sql = "UPDATE Postagens SET conteudo_Post = %s WHERE id_Post = %s"
            cursor.execute(sql, (novo_conteudo, id_post))
            conexao.commit()
            if cursor.rowcount:
                return {"sucesso": True, "mensagem": "Post atualizado com sucesso."}
            else:
                return {"sucesso": False, "mensagem": "Post não encontrado."}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ Erro editar_post: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao editar post: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Deletar post
    # -------------------------
    def deletar_post(self, id_post: int):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}
        cursor = conexao.cursor()
        try:
            sql = "DELETE FROM Postagens WHERE id_Post = %s"
            cursor.execute(sql, (id_post,))
            conexao.commit()
            if cursor.rowcount:
                return {"sucesso": True, "mensagem": "Post removido com sucesso."}
            else:
                return {"sucesso": False, "mensagem": "Post não encontrado."}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ Erro deletar_post: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao deletar post: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Curtidas: adicionar / remover / contar / verificar
    # -------------------------
    def adicionar_curtida(self, id_post: int, id_usuario: int):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}
        cursor = conexao.cursor()
        try:
            # evita duplicata
            sql_check = "SELECT id_Curtida FROM Curtidas WHERE fk_Post = %s AND fk_Usuario = %s"
            cursor.execute(sql_check, (id_post, id_usuario))
            if cursor.fetchone():
                return {"sucesso": False, "mensagem": "Usuário já curtiu este post."}

            sql = "INSERT INTO Curtidas (fk_Post, fk_Usuario) VALUES (%s, %s)"
            cursor.execute(sql, (id_post, id_usuario))
            conexao.commit()
            return {"sucesso": True, "mensagem": "Curtida adicionada."}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ Erro adicionar_curtida: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao adicionar curtida: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    def remover_curtida(self, id_post: int, id_usuario: int):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}
        cursor = conexao.cursor()
        try:
            sql = "DELETE FROM Curtidas WHERE fk_Post = %s AND fk_Usuario = %s"
            cursor.execute(sql, (id_post, id_usuario))
            conexao.commit()
            if cursor.rowcount:
                return {"sucesso": True, "mensagem": "Curtida removida."}
            else:
                return {"sucesso": False, "mensagem": "Curtida não encontrada."}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ Erro remover_curtida: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao remover curtida: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    def contar_curtidas(self, id_post: int):
        conexao = criar_conexao()
        if not conexao:
            return 0
        cursor = conexao.cursor()
        try:
            sql = "SELECT COUNT(*) FROM Curtidas WHERE fk_Post = %s"
            cursor.execute(sql, (id_post,))
            num = cursor.fetchone()[0]
            return num
        except mysql.connector.Error as e:
            print(f"❌ Erro contar_curtidas: {e}")
            return 0
        finally:
            cursor.close()
            fechar_conexao(conexao)

    def usuario_curtiu(self, id_post: int, id_usuario: int):
        conexao = criar_conexao()
        if not conexao:
            return False
        cursor = conexao.cursor()
        try:
            sql = "SELECT id_Curtida FROM Curtidas WHERE fk_Post = %s AND fk_Usuario = %s"
            cursor.execute(sql, (id_post, id_usuario))
            result = cursor.fetchone()
            return result is not None
        except mysql.connector.Error as e:
            print(f"❌ Erro usuario_curtiu: {e}")
            return False
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Comentários: adicionar / listar
    # -------------------------
    def adicionar_comentario(self, id_post: int, id_usuario: int, conteudo: str):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}
        cursor = conexao.cursor()
        try:
            agora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            sql = """
                INSERT INTO Comentarios (conteudo, data_Comentario, fk_Post, fk_Usuario)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(sql, (conteudo, agora, id_post, id_usuario))
            conexao.commit()
            return {"sucesso": True, "mensagem": "Comentário adicionado.", "id_comentario": cursor.lastrowid}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ Erro adicionar_comentario: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao adicionar comentário: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    def listar_comentarios(self, id_post: int, limit: int = 50, offset: int = 0):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT cm.*, u.nome_Usuario
                FROM Comentarios cm
                LEFT JOIN Usuario u ON cm.fk_Usuario = u.id_Usuario
                WHERE cm.fk_Post = %s
                ORDER BY cm.data_Comentario ASC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (id_post, limit, offset))
            comentarios = cursor.fetchall()
            return {"sucesso": True, "dados": comentarios}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_comentarios: {e}")
            return {"sucesso": False, "mensagem": f"Erro: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)
