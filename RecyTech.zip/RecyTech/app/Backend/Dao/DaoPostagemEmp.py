import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao
from datetime import datetime

class DaoPostagemEmp:
    def __init__(self):
        pass

    # -------------------------
    # Criar postagem
    # -------------------------
    def criar_post(self, conteudo_post: str, tipo: str, fk_usuario: int = None, fk_empresa: int = None):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor()
        try:
            sql = """
                INSERT INTO Postagens (conteudo_Post, data_Post, tipo, fk_Usuario, fk_Empresa)
                VALUES (%s, %s, %s, %s, %s)
            """
            agora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            valores = (conteudo_post, agora, tipo, fk_usuario, fk_empresa)
            cursor.execute(sql, valores)
            conexao.commit()
            id_post = cursor.lastrowid
            print(f"✅ [DEBUG] Post criado (id={id_post}) tipo={tipo}")
            return {"sucesso": True, "mensagem": "Post criado com sucesso.", "id_post": id_post}
        except mysql.connector.Error as e:
            conexao.rollback()
            print(f"❌ [DEBUG] Erro ao criar post: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao criar post: {e}"}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # Buscar post por id
    # -------------------------
    def buscar_post_por_id(self, id_post: int):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados."}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario, e.nome_Empresa
                FROM Postagens p
                LEFT JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                LEFT JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                WHERE p.id_Post = %s
            """
            cursor.execute(sql, (id_post,))
            post = cursor.fetchone()
            cursor.close()
            fechar_conexao(conexao)

            if post:
                return {"sucesso": True, "dados": post}
            else:
                return {"sucesso": False, "mensagem": "Post não encontrado."}
        except mysql.connector.Error as e:
            cursor.close()
            fechar_conexao(conexao)
            print(f"❌ Erro buscar_post_por_id: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao buscar post: {e}"}

    # -------------------------
    # Listar posts (feed) - paginado
    # -------------------------
    def listar_posts(self, limit: int = 20, offset: int = 0):
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario, e.nome_Empresa,
                    (SELECT COUNT(*) FROM Curtidas c WHERE c.fk_Post = p.id_Post) AS curtidas_count,
                    (SELECT COUNT(*) FROM Comentarios cm WHERE cm.fk_Post = p.id_Post) AS comentarios_count
                FROM Postagens p
                LEFT JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                LEFT JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                ORDER BY p.data_Post DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (limit, offset))
            posts = cursor.fetchall()
            return {"sucesso": True, "dados": posts}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_posts: {e}")
            return {"sucesso": False, "mensagem": f"Erro ao listar posts: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)

    # -------------------------
    # 🔹 Listar posts sobre reciclagem e lixo eletrônico
    # -------------------------
    def listar_feed_reciclagem(self, limit: int = 20, offset: int = 0):
        """
        Retorna apenas postagens com temas de reciclagem ou lixo eletrônico.
        Ideal para o feed da Tela Inicial Empresa.
        """
        conexao = criar_conexao()
        if not conexao:
            return {"sucesso": False, "mensagem": "Sem conexão com o banco de dados.", "dados": []}

        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
                SELECT p.*, u.nome_Usuario, e.nome_Empresa,
                    (SELECT COUNT(*) FROM Curtidas c WHERE c.fk_Post = p.id_Post) AS curtidas_count,
                    (SELECT COUNT(*) FROM Comentarios cm WHERE cm.fk_Post = p.id_Post) AS comentarios_count
                FROM Postagens p
                LEFT JOIN Usuario u ON p.fk_Usuario = u.id_Usuario
                LEFT JOIN Empresa e ON p.fk_Empresa = e.id_Empresa
                WHERE p.conteudo_Post LIKE '%reciclagem%'
                   OR p.conteudo_Post LIKE '%lixo eletrônico%'
                ORDER BY p.data_Post DESC
                LIMIT %s OFFSET %s
            """
            cursor.execute(sql, (limit, offset))
            posts = cursor.fetchall()
            return {"sucesso": True, "dados": posts}
        except mysql.connector.Error as e:
            print(f"❌ Erro listar_feed_reciclagem: {e}")
            return {"sucesso": False, "mensagem": f"Erro: {e}", "dados": []}
        finally:
            cursor.close()
            fechar_conexao(conexao)