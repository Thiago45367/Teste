# DaoUsuario.py
import mysql.connector
from app.Backend.DataBase.conexao import criar_conexao, fechar_conexao

class DaoUs:
    def __init__(self):
        self.conexao = criar_conexao()

    def cadastrar_usuario(self, usuario):
        if not self.conexao:
            print(" Sem conexão com o banco de dados")
            return None

        if self.existe_email_usuario(usuario.email_Usuario):
            print(" Email já cadastrado!")
            return None
        
        if self.existe_nome_usuario(usuario.nome_Usuario):
            print(" Nome de usuário já cadastrado!")
            return None

        cursor = self.conexao.cursor()

        sql_usuario = """
        INSERT INTO Usuario (email_Usuario, senha_Usuario, nome_Usuario, data_Nascimento)
        VALUES (%s, %s, %s, %s)
        """
        valores_usuario = (
            usuario.email_Usuario,
            usuario.senha_Usuario,
            usuario.nome_Usuario,
            usuario.data_nascimento
        )

        sql_login = """
        INSERT INTO Login (email_Login, senha_Login, tipo)
        VALUES (%s, %s, %s)
        """
        valores_login = (
            usuario.email_Usuario,
            usuario.senha_Usuario,
            "usuario"
        )

        try:
            cursor.execute(sql_usuario, valores_usuario)
            cursor.execute(sql_login, valores_login)
            self.conexao.commit()

            print(" Usuário cadastrado com sucesso (Usuario + Login)!")

            # 🔹 já busca o usuário recém cadastrado
            return self.buscar_usuario_por_email(usuario.email_Usuario)

        except mysql.connector.Error as erro:
            self.conexao.rollback()
            print(f" Erro ao cadastrar usuário: {erro}")
            return None

        finally:
            cursor.close()
            fechar_conexao(self.conexao)

    def existe_email_usuario(self, email_Usuario):
        cursor = self.conexao.cursor()
        sql = "SELECT COUNT(*) FROM Usuario WHERE email_Usuario = %s"
        cursor.execute(sql, (email_Usuario,))
        (quantidade,) = cursor.fetchone()
        cursor.close()
        return quantidade > 0
    
    def existe_nome_usuario(self, nome_Usuario):
        cursor = self.conexao.cursor()
        sql = "SELECT COUNT(*) FROM Usuario WHERE nome_Usuario = %s"
        cursor.execute(sql, (nome_Usuario,))
        (quantidade,) = cursor.fetchone()
        cursor.close()
        return quantidade > 0

    def buscar_usuario_por_email(self, email):
        """🔹 Retorna dados do usuário (dict) pelo email"""
        if not self.conexao:
            print(" Sem conexão com o banco de dados")
            return None

        cursor = self.conexao.cursor(dictionary=True)
        sql = "SELECT id_Usuario, nome_Usuario, email_Usuario, NULL as foto FROM Usuario WHERE email_Usuario = %s"
        cursor.execute(sql, (email,))
        usuario = cursor.fetchone()
        cursor.close()

        if usuario:
            # 🔹 Mapeia para o padrão que o app espera
            return {
                "id": usuario["id_Usuario"],
                "nome": usuario["nome_Usuario"],
                "email": usuario["email_Usuario"],
                "foto": usuario.get("foto") or "app/Frontend/Assets/Foto_Perfil.png"
            }
        return None
