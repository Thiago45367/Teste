class ModeloEmpresa:
    def __init__(self, cnpj: str, nome_Empresa: str, telefone_Empresa: str, fk_Login: int = None, id_Empresa: int = None):
        self.id_Empresa = id_Empresa
        self.cnpj = cnpj
        self.nome_Empresa = nome_Empresa
        self.telefone_Empresa = telefone_Empresa
        self.fk_Login = fk_Login   # 🔹 agora empresa só aponta para Login
