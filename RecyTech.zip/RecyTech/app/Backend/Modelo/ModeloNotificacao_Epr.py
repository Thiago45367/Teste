import datetime

class ModeloNotificacao_Epr:
    def __init__(self, id_Notificacao_Epr: int, data_Envie: datetime, descricao_Epr: str, fk_Empresa: int):
        self.id_Notificacao_Epr = id_Notificacao_Epr
        self.data_Envie = data_Envie
        self.descricao_Epr = descricao_Epr
        self.fk_Empresa = fk_Empresa