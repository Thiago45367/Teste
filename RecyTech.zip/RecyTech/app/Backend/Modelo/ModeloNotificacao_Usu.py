import datetime

class ModeloNotificacao_Usu:
    def __init__(self, id_Notificacao_Us: int, data_Envio: datetime, descricao: str, fk_Empresa: int, fk_Usuario: int):
        self.id_Notificacao_Us = id_Notificacao_Us
        self.data_Envio = data_Envio
        self.descricao = descricao
        self.fk_Empresa = fk_Empresa
        self.fk_Usuario = fk_Usuario