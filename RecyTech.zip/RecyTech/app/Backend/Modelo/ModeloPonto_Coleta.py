from datetime import datetime

class ModeloPontoColeta:
    def __init__(self, nome_Ponto, cep, numero_Endereco_Ponto, horario, tipo_Coleta, remuneracao, latitude, longitude, fk_Empresa=None):
        self.nome_Ponto = nome_Ponto
        self.cep = cep
        self.numero_Endereco_Ponto = numero_Endereco_Ponto  # novo campo
        self.horario = horario
        self.tipo_Coleta = tipo_Coleta
        self.remuneracao = remuneracao
        self.latitude = latitude
        self.longitude = longitude
        self.fk_Empresa = fk_Empresa