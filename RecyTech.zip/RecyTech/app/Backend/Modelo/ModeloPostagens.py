import datetime

class ModeloPostagens:
    def __init__(self, id_Post: int, id_Usuario: int, conteudo_Post: str, data_Post: datetime, tipo: str):
        self.id_Post = id_Post
        self.id_Usuario = id_Usuario
        self.conteudo_Post = conteudo_Post
        self.data_Post = data_Post
        self.tipo = tipo