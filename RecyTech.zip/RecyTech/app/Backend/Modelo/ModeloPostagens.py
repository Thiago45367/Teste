import datetime

class ModeloPostagens:
    def __init__(self, id_Post=None, id_Usuario=None, id_Empresa=None, conteudo_Post="", data_Post=None, tipo="empresa"):
        self.id_Post = id_Post
        self.id_Usuario = id_Usuario   # 🔹 agora compatível com ControlePostagemEmp
        self.id_Empresa = id_Empresa   # 🔹 adicionado para empresas
        self.conteudo_Post = conteudo_Post
        self.data_Post = data_Post if data_Post else datetime.datetime.now()
        self.tipo = tipo