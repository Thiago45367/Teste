import datetime

class ModeloUsuario:
    def __init__(self, email_Usuario: str, senha_Usuario: str, nome_Usuario: str, data_nascimento: datetime, id_usuario = None):
        self.id_usuario = id_usuario
        self.email_Usuario = email_Usuario
        self.senha_Usuario = senha_Usuario
        self.nome_Usuario = nome_Usuario
        self.data_nascimento = data_nascimento