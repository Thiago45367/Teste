from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.metrics import dp, sp
from kivy.graphics import Color, RoundedRectangle

# 🔹 Importação para controle das postagens
from app.Backend.Controle.ControlePostagemEmp import ControlePostagemEmp

interface_TelaInicioEmp = '''
<HeaderEmpresa>:
    size_hint_y: None
    height: dp(70)
    padding: dp(10)
    spacing: dp(12)
    canvas.before:
        Color:
            rgba: 0.9, 0.9, 0.9, 1
        Rectangle:
            pos: self.pos
            size: self.size

    FotoPerfil:
        id: foto_perfil
        size_hint: None, None
        size: dp(55), dp(55)
        pos_hint: {"center_y": 0.5}
        source: app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png"

    Label:
        id: lbl_nome
        text: app.empresa_nome if app.empresa_nome else "Empresa"
        font_size: sp(18)
        color: 0, 0, 0, 1
        halign: "left"
        valign: "middle"
        text_size: self.size
        size_hint_y: None
        height: dp(55)
        pos_hint: {"center_y": 0.5}

<TelaInicialEmpresa>:
    BoxLayout:
        orientation: "vertical"
        padding: 0
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 1, 1, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        HeaderEmpresa:
            id: header

        # 🔹 Botão para criar nova postagem
        BoxLayout:
            size_hint_y: None
            height: dp(60)
            padding: dp(10)
            Button:
                text: "➕ Nova Postagem"
                font_size: sp(16)
                size_hint_x: 1
                background_color: 0.2, 0.6, 0.2, 1
                color: 1, 1, 1, 1
                on_release: root.abrir_popup_nova_postagem()

        BoxLayout:
            orientation: "vertical"
            padding: dp(8)
            spacing: dp(12)
            size_hint_y: 1

            ScrollView:
                do_scroll_x: False
                BoxLayout:
                    id: feed
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(12)

                    Label:
                        text: "Não há postagens no momento"
                        font_size: sp(18)
                        color: 0,0,0,1
                        halign: "center"
                        valign: "middle"
                        size_hint_y: None
                        height: self.texture_size[1] + dp(20)

        # 🔹 Barra inferior
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''

Builder.load_string(interface_TelaInicioEmp)


class IconButton(ButtonBehavior, Image):
    pass


# 🟩 Mantido 100% do código 1 (menu de perfil completo com botão sair)
class FotoPerfil(ButtonBehavior, Image):
    def on_release(self):
        self.abrir_menu_lateral()

    def abrir_menu_lateral(self):
        app = App.get_running_app()

        menu = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(6))
        with menu.canvas.before:
            Color(0.94, 0.93, 0.85, 0.98)
            self.bg_rect = RoundedRectangle(radius=[0, 0, dp(10), dp(10)], pos=menu.pos, size=menu.size)
            Color(0.55, 0.55, 0.55, 1)
            self.left_border = RoundedRectangle(pos=(menu.x, menu.y), size=(dp(6), menu.height))
            self.right_border = RoundedRectangle(pos=(menu.right - dp(6), menu.y), size=(dp(6), menu.height))
            self.bottom_border = RoundedRectangle(pos=(menu.x, menu.y), size=(menu.width, dp(6)))

        def atualizar_bordas(*_):
            self.left_border.pos = (menu.x, menu.y)
            self.left_border.size = (dp(6), menu.height)
            self.right_border.pos = (menu.right - dp(6), menu.y)
            self.right_border.size = (dp(6), menu.height)
            self.bottom_border.pos = (menu.x, menu.y)
            self.bottom_border.size = (menu.width, dp(6))
            self.bg_rect.pos = menu.pos
            self.bg_rect.size = menu.size

        menu.bind(pos=atualizar_bordas, size=atualizar_bordas)

        linha_topo = BoxLayout(orientation='horizontal', spacing=dp(10), size_hint_y=None, height=dp(55))
        foto = Image(
            source=app.empresa_foto if app.empresa_foto else "app/Frontend/Assets/Foto_Perfil.png",
            size_hint=(None, None),
            size=(dp(50), dp(50))
        )
        nome = Label(
            text=f"[b]{app.empresa_nome if app.empresa_nome else 'Empresa'}[/b]",
            markup=True,
            font_size=sp(17),
            color=(0, 0, 0, 1),
            halign='left',
            valign='middle'
        )
        nome.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        linha_topo.add_widget(foto)
        linha_topo.add_widget(nome)
        menu.add_widget(linha_topo)
        menu.add_widget(Label(size_hint_y=None, height=dp(15)))

        linha_sair = BoxLayout(
            orientation='horizontal',
            spacing=dp(8),
            size_hint_y=None,
            height=dp(45),
            padding=[dp(10), dp(5), dp(10), dp(5)]
        )
        icone_sair = Image(
            source="app/Frontend/Assets/Sair.png",
            size_hint=(None, None),
            size=(dp(25), dp(25)),
            pos_hint={"center_y": 0.5}
        )
        lbl_sair = Button(
            text="Sair",
            background_normal='',
            background_color=(0, 0, 0, 0),
            color=(0, 0, 0, 1),
            font_size=sp(15),
            halign='left',
            valign='middle'
        )
        lbl_sair.bind(size=lambda inst, val: setattr(inst, 'text_size', val))
        lbl_sair.bind(on_release=self.sair)

        linha_sair.add_widget(icone_sair)
        linha_sair.add_widget(lbl_sair)
        menu.add_widget(linha_sair)

        self.popup = Popup(
            title='',
            content=menu,
            size_hint=(0.36, 0.30),
            pos_hint={"x": -0.02, "top": 1.06},
            background_color=(0, 0, 0, 0),
            separator_height=0,
            auto_dismiss=True
        )
        self.popup.open()

    def sair(self, instance):
        if hasattr(self, 'popup'):
            self.popup.dismiss()
        app = App.get_running_app()
        try:
            app.root.current = "TelaLogin"
        except Exception:
            print("⚠️ Erro ao voltar para TelaLogin")


class HeaderEmpresa(BoxLayout):
    pass


class TelaInicialEmpresa(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()
        self.ids.header.ids.lbl_nome.text = app.empresa_nome if app.empresa_nome else "Empresa"
        self.carregar_postagens()

    def ir_para_home(self): ...
    def ir_para_reciclar(self):
        App.get_running_app().root.current = "TelaMapaEmp"
    def ir_para_notificacoes(self):
        App.get_running_app().root.current = "TelaNotificacaoEmp"

    # 🔹 Carrega postagens do backend
    def carregar_postagens(self):
        self.ids.feed.clear_widgets()
        controle = ControlePostagemEmp()
        resultado = controle.listar_postagens()

        if resultado["sucesso"] and resultado["dados"]:
            for post in resultado["dados"]:
                autor = post.get("nome_Empresa") or post.get("nome_Usuario") or "Autor desconhecido"
                card = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(5), size_hint_y=None, height=dp(120))
                card.add_widget(Label(text=f"[b]{autor}[/b]", markup=True, color=(0,0,0,1), font_size=sp(16)))
                card.add_widget(Label(text=post['conteudo_Post'][:120] + "...", color=(0.2,0.2,0.2,1), font_size=sp(14)))
                card.bind(on_touch_down=lambda inst, touch, p=post: self.abrir_popup_post(p) if inst.collide_point(*touch.pos) else None)
                self.ids.feed.add_widget(card)
        else:
            self.ids.feed.add_widget(Label(text="Nenhuma postagem encontrada", font_size=sp(16), color=(0,0,0,1)))

    # 🔹 Abre popup com postagem detalhada
    def abrir_popup_post(self, post):
        autor = post.get("nome_Empresa") or post.get("nome_Usuario") or "Autor desconhecido"
        conteudo = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(10))
        conteudo.add_widget(Label(text=f"[b]{autor}[/b]\\n{post['conteudo_Post']}", markup=True, color=(0,0,0,1), font_size=sp(15)))
        popup = Popup(title="Postagem", content=conteudo, size_hint=(0.85, 0.6))
        popup.open()

    # 🟦 Mantido do código 2, mas integrado ao backend
    def abrir_popup_nova_postagem(self):
        box = BoxLayout(orientation='vertical', spacing=dp(10), padding=dp(10))
        txt = TextInput(hint_text="Escreva sua postagem aqui...", multiline=True, size_hint_y=0.7)
        btn_publicar = Button(text="Publicar", size_hint_y=0.3, background_color=(0.2, 0.6, 0.2, 1), color=(1,1,1,1))

        box.add_widget(txt)
        box.add_widget(btn_publicar)

        popup = Popup(title="Nova Postagem", content=box, size_hint=(0.9, 0.5), auto_dismiss=True)

        def publicar(_):
            conteudo = txt.text.strip()
            if conteudo:
                controle = ControlePostagemEmp()
                resultado = controle.criar_postagem(conteudo)
                print("🟢 Resultado da postagem:", resultado)
                self.adicionar_postagem_local(conteudo)
                popup.dismiss()

        btn_publicar.bind(on_release=publicar)
        popup.open()

    
    # 🔹 Adiciona postagem no feed localmente
    def adicionar_postagem_local(self, conteudo):
        # 🔸 Remove o texto "Não há postagens no momento" se existir
        for widget in list(self.ids.feed.children):
            if isinstance(widget, Label) and "postagens" in widget.text:
                self.ids.feed.remove_widget(widget)

        # 🔸 Adiciona a nova postagem ao feed
        card = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(5), size_hint_y=None, height=dp(100))
        card.add_widget(Label(text=f"[b]{App.get_running_app().empresa_nome or 'Empresa'}[/b]",
                              markup=True, color=(0, 0, 0, 1), font_size=sp(16)))
        card.add_widget(Label(text=conteudo, color=(0.2, 0.2, 0.2, 1), font_size=sp(14)))
        self.ids.feed.add_widget(card)