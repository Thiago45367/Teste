# TelaMapaEmp.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy_garden.mapview import MapView, MapMarkerPopup, MapSource
from kivy.metrics import dp
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.clock import Clock
from app.Backend.Controle.ControleEmp import ControleEmp
from app.Backend.Controle.ControleLogin import ControleLogin

interface_TelaMapaEmp = '''
<TelaMapaEmpresa>:
    BoxLayout:
        orientation: "vertical"

        BoxLayout:
            orientation: "horizontal"
            size_hint_y: 0.9
            spacing: dp(5)

            BrasilMapView:
                id: mapview
                zoom: 5
                lat: -14.2350
                lon: -51.9253
                double_tap_zoom: True
                min_zoom: 4
                max_zoom: 14

            BoxLayout:
                id: painel_cadastro
                orientation: "vertical"
                size_hint_x: 0.4
                padding: dp(10)
                spacing: dp(8)
                canvas.before:
                    Color:
                        rgba: 1, 0.95, 0.6, 1   # 💛 Amarelo claro
                    Rectangle:
                        pos: self.pos
                        size: self.size

                Label:
                    text: "Cadastrar Ponto de Coleta"
                    font_size: sp(18)
                    bold: True
                    color: 0,0,0,1
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: nome_input
                    hint_text: "Nome do Ponto"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: cep_input
                    hint_text: "CEP (somente números)"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: numero_input
                    hint_text: "Número do Endereço"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: horario_input
                    hint_text: "Horário (HH:MM)"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: tipo_input
                    hint_text: "Tipo de Coleta"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                TextInput:
                    id: remuneracao_input
                    hint_text: "Remuneração"
                    multiline: False
                    size_hint_y: None
                    height: dp(40)

                Button:
                    text: "Salvar Ponto"
                    size_hint_y: None
                    height: dp(45)
                    background_color: 0, 0.6, 0, 1
                    on_release: root.salvar_ponto()

        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    color: 0,0,0,1
                    halign: "center"
                    valign: "middle"
                    text_size: self.size

            Widget:
                size_hint_x: None
                width: dp(1)

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    color: 0,0,0,1
                    halign: "center"
                    valign: "middle"
                    text_size: self.size

            Widget:
                size_hint_x: None
                width: dp(1)

            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    color: 0,0,0,1
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
'''

Builder.load_string(interface_TelaMapaEmp)

class IconButton(ButtonBehavior, Image):
    pass

class BrasilMapView(MapView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # map_source como MapSource para usar base carto (limpo)
        self.map_source = MapSource(
            url="https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
            attribution="© OpenStreetMap contributors, © CARTO",
            tile_size=256,
            min_zoom=1,
            max_zoom=19
        )

class TelaMapaEmpresa(Screen):
    def on_pre_enter(self):
        # espera até o mapa estar pronto para evitar erros (parent/transform None)
        Clock.schedule_once(self._try_carregar_pontos, 0.6)

    def _try_carregar_pontos(self, dt):
        mapview = self.ids.get("mapview")
        if mapview is None or mapview.parent is None:
            Clock.schedule_once(self._try_carregar_pontos, 0.5)
            return
        self.carregar_pontos()

    def salvar_ponto(self):
        nome = self.ids.nome_input.text.strip()
        cep = self.ids.cep_input.text.strip()
        numero = self.ids.numero_input.text.strip()
        horario = self.ids.horario_input.text.strip()
        tipo = self.ids.tipo_input.text.strip()
        remuneracao = self.ids.remuneracao_input.text.strip()

        if not ControleLogin.usuario_logado or ControleLogin.usuario_logado["tipo"] != "empresa":
            self.mostrar_popup(" Nenhuma empresa está logada. Faça login novamente.")
            return

        controle = ControleEmp()
        # assinatura do controle: cadastrar_ponto(nome, cep, numero_Endereco_Ponto, horario, tipo_Coleta, remuneracao)
        resultado = controle.cadastrar_ponto(nome, cep, numero, horario, tipo, remuneracao)

        if isinstance(resultado, dict) and resultado.get("sucesso"):
            self.mostrar_popup(" Ponto cadastrado com sucesso!")
            self.carregar_pontos()
            self.limpar_campos()
        else:
            # resultado pode ser dict com "mensagem" ou str
            msg = resultado.get("mensagem") if isinstance(resultado, dict) else str(resultado)
            self.mostrar_popup(msg or "Erro ao cadastrar ponto.")

    def carregar_pontos(self):
        try:
            controle = ControleEmp()
            resposta = controle.listar_pontos()
            pontos = resposta.get("dados", []) if isinstance(resposta, dict) else resposta
            print(f" Pontos carregados: {len(pontos)}")

            mapview = self.ids.mapview

            # remove somente marcadores adicionados (mantém internals do MapView)
            # usamos isinstance em MapMarkerPopup/MapMarker
            from kivy_garden.mapview import MapMarker, MapMarkerPopup
            for child in list(mapview.children):
                if isinstance(child, (MapMarker, MapMarkerPopup)):
                    try:
                        mapview.remove_widget(child)
                    except Exception:
                        pass

            lats, lons = [], []

            for ponto in pontos:
                try:
                    # pontos vem como dict do DAO (colunas selecionadas no DAO)
                    lat = float(ponto.get("latitude", ponto.get("lat", 0)) or 0)
                    lon = float(ponto.get("longitude", ponto.get("lon", 0)) or 0)
                    nome = ponto.get("nome_Ponto", ponto.get("nome", "Ponto"))
                    numero = ponto.get("numero_Endereco_Ponto", ponto.get("numero", "") or "")
                    tipo = ponto.get("tipo_Coleta", ponto.get("tipo", "") or "")
                    remuneracao = ponto.get("remuneracao", "") or ""
                    cep = ponto.get("cep", "") or ""
                    id_ponto = ponto.get("id_Ponto_Coleta") or ponto.get("id", None)
                except Exception:
                    continue

                if not lat or not lon:
                    continue

                lats.append(lat)
                lons.append(lon)

                # MapMarkerPopup permite widget dentro, mas vamos abrir popup custom ao clicar
                marker = MapMarkerPopup(lat=lat, lon=lon, source="app/Frontend/Assets/PontoColeta.png")
                marker.size = (dp(48), dp(48))

                # guardar os dados no marker para quando for clicado
                marker.ponto_data = {
                    "id": id_ponto,
                    "nome": nome,
                    "cep": cep,
                    "numero": numero,
                    "horario": ponto.get("horario", ""),
                    "tipo": tipo,
                    "remuneracao": remuneracao,
                    "latitude": lat,
                    "longitude": lon,
                    "fk_Empresa": ponto.get("fk_Empresa")
                }

                # bind on_release para abrir painel detalhado; evitar problema com closure usando default arg
                marker.bind(on_release=lambda m, p=marker.ponto_data: self.abrir_detalhes_ponto(p))

                mapview.add_widget(marker)

            if lats and lons:
                avg_lat, avg_lon = sum(lats)/len(lats), sum(lons)/len(lons)
                mapview.center_on(avg_lat, avg_lon)
                mapview.zoom = 12 if len(lats) <= 5 else 10

            print(" Pontos plotados no mapa com sucesso.")

        except Exception as e:
            print(" Erro inesperado ao carregar pontos:", e)

    def abrir_detalhes_ponto(self, ponto: dict):
        """Abre um popup estilizado (amarelo) com dados do ponto."""
        try:
            # layout principal
            root = BoxLayout(orientation="vertical", padding=15, spacing=10)
            root.canvas.before.clear()
            from kivy.graphics import Color, Rectangle
            with root.canvas.before:
                Color(1, 0.95, 0.6, 1)  # 💛 Fundo amarelo
                Rectangle(pos=root.pos, size=root.size)
            root.bind(pos=lambda *_: setattr(root.canvas.before.children[-1], "pos", root.pos))
            root.bind(size=lambda *_: setattr(root.canvas.before.children[-1], "size", root.size))

            # título
            titulo = Label(
                text=f" {ponto.get('nome', 'Ponto de Coleta')}",
                font_size='18sp',
                bold=True,
                color=(0, 0, 0, 1),
                size_hint_y=None,
                height=dp(40)
            )
            root.add_widget(titulo)

            # conteúdo (grid)
            content = GridLayout(cols=2, spacing=6, padding=[10, 5])
            def add_row(label_text, value_text):
                lbl = Label(text=f"[b]{label_text}:[/b]", markup=True, color=(0, 0, 0, 1),
                            size_hint_y=None, height=dp(28), halign="right", valign="middle")
                val = Label(text=str(value_text or "-"), color=(0, 0, 0, 1),
                            size_hint_y=None, height=dp(28), halign="left", valign="middle")
                lbl.text_size = (None, None)
                val.text_size = (None, None)
                content.add_widget(lbl)
                content.add_widget(val)

            add_row("Nome", ponto.get("nome"))
            add_row("CEP", ponto.get("cep"))
            add_row("Número", ponto.get("numero"))
            add_row("Horário", ponto.get("horario"))
            add_row("Tipo", ponto.get("tipo"))
            add_row("Remuneração", ponto.get("remuneracao"))
            root.add_widget(content)

            # botões
            botoes = BoxLayout(size_hint_y=None, height=dp(50), spacing=10, padding=[0, 10, 0, 0])
            btn_center = Button(text="Centralizar no mapa",
                                background_color=(0, 0.6, 0, 1))
            btn_close = Button(text="Fechar",
                               background_color=(0.8, 0.1, 0.1, 1))
            botoes.add_widget(btn_center)
            botoes.add_widget(btn_close)
            root.add_widget(botoes)

            # popup adaptado pra celular (tamanho 85% tela)
            popup = Popup(
                title="",
                content=root,
                size_hint=(0.85, 0.5),
                auto_dismiss=False,
                background_color=(1, 0.95, 0.6, 1)
            )

            # funções dos botões
            def fechar(_): popup.dismiss()

            def centralizar(_):
                try:
                    lat = float(ponto.get("latitude"))
                    lon = float(ponto.get("longitude"))
                    mv = self.ids.mapview
                    mv.center_on(lat, lon)
                    mv.zoom = max(mv.zoom, 14)
                except Exception as e:
                    print("Erro ao centralizar:", e)

            btn_close.bind(on_release=fechar)
            btn_center.bind(on_release=centralizar)
            popup.open()

        except Exception as e:
            print(" Erro ao abrir detalhes do ponto:", e)

    def limpar_campos(self):
        for campo in ["nome_input", "cep_input", "numero_input", "horario_input", "tipo_input", "remuneracao_input"]:
            try:
                self.ids[campo].text = ""
            except Exception:
                pass

    def mostrar_popup(self, mensagem):
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        layout.add_widget(Label(text=mensagem))
        btn = Button(text="Fechar", size_hint_y=None, height=40)
        layout.add_widget(btn)
        popup = Popup(title="Aviso", content=layout, size_hint=(0.6, 0.4))
        btn.bind(on_release=popup.dismiss)
        popup.open()

    def ir_para_home(self): self.manager.current = "TelaInicioEmp" if self.manager else None
    def ir_para_reciclar(self): pass
    def ir_para_notificacoes(self): self.manager.current = "TelaNotificacaoEmp" if self.manager else None


class TelaMapaApp(App):
    def build(self):
        return TelaMapaEmpresa()


if __name__ == "__main__":
    TelaMapaApp().run()