from kivy.app import App
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.metrics import dp, sp

interface_TelaNotificacaoEmp = '''
<TelaNotificacoesEmp>:
    BoxLayout:
        orientation: "vertical"
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 1, 1, 0.5, 1
            Rectangle:
                pos: self.pos
                size: self.size

        # ----- Barra de Pesquisa -----
        BoxLayout:
            size_hint_y: None
            height: dp(55)
            spacing: dp(8)
            padding: [dp(10), dp(5), dp(10), dp(5)]

            canvas.before:
                Color:
                    rgba: 0.95, 0.95, 0.95, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [12]

            IconButton:
                source: "app/Frontend/Assets/Pesquisa.png"
                size_hint: None, None
                size: dp(28), dp(28)
                pos_hint: {"center_y": .5}

            TextInput:
                id: search_input
                hint_text: "Pesquisar notificações..."
                multiline: False
                size_hint_x: 1
                background_normal: ""
                background_active: ""
                background_color: 1,1,1,1
                foreground_color: 0,0,0,1
                cursor_color: 0,0,0,1
                font_size: sp(14)
                padding: [dp(4), dp(4), dp(4), dp(4)]

            IconButton:
                source: "app/Frontend/Assets/Configuração.png"
                size_hint: None, None
                size: dp(28), dp(28)
                pos_hint: {"center_y": .5}
                on_press: root.ir_para_config()

        # ----- Título -----
        BoxLayout:
            size_hint_y: None
            height: dp(30)
            padding: [dp(10), 0, 0, 0]
            Label:
                markup: True
                text: "[b]Todos[/b]"
                halign: "left"
                valign: "middle"
                text_size: self.size
                color: 0,0,0,1

        # ----- Lista de Notificações -----
        ScrollView:
            do_scroll_x: False
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: self.minimum_height
                spacing: dp(12)
                padding: dp(10)

                # ---- Card 1 ----
                BoxLayout:
                    size_hint_y: None
                    height: dp(70)
                    padding: dp(10)
                    spacing: dp(10)
                    canvas.before:
                        Color:
                            rgba: 0, 0, 0, 0.15
                        RoundedRectangle:
                            pos: self.x+2, self.y-2
                            size: self.size
                            radius: [12]
                        Color:
                            rgba: 1, 1, 1, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [12]

                    Image:
                        source: "app/Frontend/Assets/Reciclagem.png"
                        size_hint_x: None
                        width: dp(45)

                    Label:
                        text: "O cliente João Silva agendou uma coleta de lixo eletrônico para o dia 07/06/2025 às 14h"
                        color: 0,0,0,1
                        halign: "left"
                        valign: "middle"
                        text_size: self.size

                # ---- Card 2 ----
                BoxLayout:
                    size_hint_y: None
                    height: dp(70)
                    padding: dp(10)
                    spacing: dp(10)
                    canvas.before:
                        Color:
                            rgba: 0, 0, 0, 0.15
                        RoundedRectangle:
                            pos: self.x+2, self.y-2
                            size: self.size
                            radius: [12]
                        Color:
                            rgba: 1, 1, 1, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [12]

                    Image:
                        source: "app/Frontend/Assets/Reciclagem.png"
                        size_hint_x: None
                        width: dp(45)

                    Label:
                        text: "A coleta marcada para 06/06/2025 às 10h com Maria foi cancelada"
                        color: 0,0,0,1
                        halign: "left"
                        valign: "middle"
                        text_size: self.size

                # ---- Card 3 ----
                BoxLayout:
                    size_hint_y: None
                    height: dp(70)
                    padding: dp(10)
                    spacing: dp(10)
                    canvas.before:
                        Color:
                            rgba: 0, 0, 0, 0.15
                        RoundedRectangle:
                            pos: self.x+2, self.y-2
                            size: self.size
                            radius: [12]
                        Color:
                            rgba: 1, 1, 1, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [12]

                    Image:
                        source: "app/Frontend/Assets/Reciclagem.png"
                        size_hint_x: None
                        width: dp(45)

                    Label:
                        text: "O cliente Eduardo Lima solicitou uma coleta para o mesmo dia, até às 17h"
                        color: 0,0,0,1
                        halign: "left"
                        valign: "middle"
                        text_size: self.size

                # ---- Card 4 ----
                BoxLayout:
                    size_hint_y: None
                    height: dp(70)
                    padding: dp(10)
                    spacing: dp(10)
                    canvas.before:
                        Color:
                            rgba: 0, 0, 0, 0.15
                        RoundedRectangle:
                            pos: self.x+2, self.y-2
                            size: self.size
                            radius: [12]
                        Color:
                            rgba: 1, 1, 1, 1
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [12]

                    Image:
                        source: "app/Frontend/Assets/Reciclagem.png"
                        size_hint_x: None
                        width: dp(45)

                    Label:
                        text: "Cliente Luciana Andrade avaliou a última coleta com 5 estrelas"
                        color: 0,0,0,1
                        halign: "left"
                        valign: "middle"
                        text_size: self.size

        # ----- Barra inferior -----
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            spacing: dp(30)
            padding: dp(10)

            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            # Aba Início
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                spacing: dp(2)

                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            # divisor
            Widget:
                size_hint_x: None
                width: 1
                canvas.before:
                    Color:
                        rgba: 0.3, 0.3, 0.3, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Reciclar
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                spacing: dp(2)

                IconButton:
                    source: "app/Frontend/Assets/PontoColeta.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            # divisor
            Widget:
                size_hint_x: None
                width: 1
                canvas.before:
                    Color:
                        rgba: 0.3, 0.3, 0.3, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Notificações
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                spacing: dp(2)

                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''

Builder.load_string(interface_TelaNotificacaoEmp)


class IconButton(ButtonBehavior, Image):
    pass


class TelaNotificacoesEmp(Screen):
    def ir_para_config(self):
        box = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(10))
        box.add_widget(Label(text="Configurações", size_hint_y=None, height=dp(30)))
        btn_close = Button(text="Fechar", size_hint_y=None, height=dp(40))
        box.add_widget(btn_close)
        popup = Popup(title="Configurações", content=box, size_hint=(0.6, 0.4), auto_dismiss=True)
        btn_close.bind(on_release=popup.dismiss)
        popup.open()

    def ir_para_home(self):
        if self.manager:
            self.manager.current = "TelaInicioEmp"

    def ir_para_reciclar(self):
        if self.manager:
            self.manager.current = "TelaMapaEmp"

    def ir_para_notificacoes(self):
        pass