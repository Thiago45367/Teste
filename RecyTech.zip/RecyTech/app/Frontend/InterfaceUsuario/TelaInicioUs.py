# TelaInicioUs.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen

# 🔹 KV carregado apenas uma vez
interface_TelaInicioUs = '''
<HeaderUsuario>:
    size_hint_y: None
    height: dp(55)
    padding: dp(10)
    spacing: dp(10)
    canvas.before:
        Color:
            rgba: 0.9, 0.9, 0.9, 1
        Rectangle:
            pos: self.pos
            size: self.size

    Image:
        size_hint: None, None
        size: dp(38), dp(38)
        source: app.usuario_foto if app.usuario_foto else "app/Frontend/Assets/Foto_Perfil.png"

    Label:
        id: lbl_nome
        text: app.usuario_nome if app.usuario_nome else "Usuário"
        font_size: sp(16)
        color: 0,0,0,1
        halign: "left"
        valign: "middle"
        text_size: self.size

<TelaInicialUsuario>:
    BoxLayout:
        orientation: "vertical"
        padding: 0
        spacing: dp(8)

        canvas.before:
            Color:
                rgba: 0.4, 0.8, 0.4, 1  # fundo verde
            Rectangle:
                pos: self.pos
                size: self.size

        # ----- CABEÇALHO -----
        HeaderUsuario:
            id: header

        # ----- CONTEÚDO -----
        BoxLayout:
            orientation: "vertical"
            padding: dp(8)
            spacing: dp(12)
            size_hint_y: 1

            ScrollView:
                do_scroll_x: False
                BoxLayout:
                    id: feed
                    orientation: "vertical"
                    size_hint_y: None
                    height: self.minimum_height
                    spacing: dp(12)

                    Label:
                        text: "Não há postagens no momento"
                        font_size: sp(18)
                        color: 0,0,0,1
                        halign: "center"
                        valign: "middle"
                        size_hint_y: None
                        height: self.texture_size[1] + dp(20)

        # ----- BARRA INFERIOR -----
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            padding: dp(5)
            spacing: dp(0)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            # Aba Início
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Reciclar
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Reciclagem.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            Widget:
                size_hint_x: None
                width: dp(1)
                canvas.before:
                    Color:
                        rgba: 0,0,0,0.3
                    Rectangle:
                        pos: self.pos
                        size: self.size

            # Aba Notificações
            BoxLayout:
                orientation: "vertical"
                size_hint_x: 1
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: root.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(13)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

'''

# 🔹 Carregamento único
Builder.load_string(interface_TelaInicioUs)

class HeaderUsuario(BoxLayout):
    pass

class IconButton(ButtonBehavior, Image):
    pass

class TelaInicialUsuario(Screen):
    def on_pre_enter(self, *args):
        app = App.get_running_app()

        # força sincronização visual (mesmo com bind já deveria atualizar)
        self.ids.header.ids.lbl_nome.text = app.usuario_nome if app.usuario_nome else "Usuário"

    def ir_para_home(self): ...

    def ir_para_reciclar(self):
        app = App.get_running_app()
        app.root.current = "TelaMapaUs"

    def ir_para_notificacoes(self): ...