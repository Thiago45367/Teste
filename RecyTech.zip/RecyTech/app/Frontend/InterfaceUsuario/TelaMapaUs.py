from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.screenmanager import Screen

interface_TelaMapaUs = '''
<TelaMapaUsuario>:
    BoxLayout:
        orientation: "vertical"

        # ----- CONTEÚDO PRINCIPAL (mapa + opções) -----
        BoxLayout:
            orientation: "vertical"
            size_hint_y: 0.9
            spacing: 0

            # ----- ÁREA DO MAPA -----
            BoxLayout:
                size_hint_y: 0.7
                padding: dp(5)
                canvas.before:
                    Color:
                        rgba: 1, 1, 1, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

                Label:
                    text: "[Mapa aparecerá aqui futuramente]"
                    markup: True
                    color: 0,0,0,1

            # ----- OPÇÕES (Filtros e SOS) -----
            AnchorLayout:   
                size_hint_y: 0.3
                anchor_y: "center"   # centraliza verticalmente
                canvas.before:
                    Color:
                        rgba: 0.4, 0.8, 0.4, 1
                    Rectangle:
                        pos: self.pos
                        size: self.size

                BoxLayout:
                    orientation: "vertical"
                    padding: [10, 0, 10, 0]   # só margem lateral
                    spacing: dp(20)
                    size_hint_y: None
                    height: self.minimum_height
                    anchor_x: "left"

                    # Botão Filtrar Pontos de Coleta
                    BoxLayout:
                        orientation: "horizontal"
                        size_hint_y: None
                        height: dp(30)
                        spacing: dp(10)
                        Image:
                            source: "app/Frontend/Assets/Funil.png"
                            size_hint: None, None
                            size: dp(30), dp(30)
                        Button:
                            text: "Filtrar Pontos de Coletas"
                            background_normal: ""  
                            background_color: 0, 0, 0, 0
                            color: 0,0,0,1
                            halign: "left"
                            valign: "middle"
                            text_size: self.size
                            on_press: app.filtrar_pontos()

                    # Botão Ajuda SOS
                    BoxLayout:
                        orientation: "horizontal"
                        size_hint_y: None
                        height: dp(30)
                        spacing: dp(10)
                        Image:
                            source: "app/Frontend/Assets/Help.png"
                            size_hint: None, None
                            size: dp(30), dp(30)
                        Button:
                            text: "Ajuda SOS"
                            background_normal: ""
                            background_color: 0, 0, 0, 0
                            color: 1,0,0,1
                            halign: "left"
                            valign: "middle"
                            text_size: self.size
                            on_press: app.pedir_ajuda()

        # ----- BARRA INFERIOR -----
        BoxLayout:
            size_hint_y: None
            height: dp(70)
            spacing: dp(30)
            padding: dp(10)
            canvas.before:
                Color:
                    rgba: 0.5, 0.5, 0.5, 1
                Rectangle:
                    pos: self.pos
                    size: self.size

            # Aba Início
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                IconButton:
                    source: "app/Frontend/Assets/Home.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: app.ir_para_home()
                Label:
                    text: "Início"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            # Aba Reciclar
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                IconButton:
                    source: "app/Frontend/Assets/Reciclagem.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: app.ir_para_reciclar()
                Label:
                    text: "Reciclar"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1

            # Aba Notificações
            BoxLayout:
                orientation: "vertical"
                padding: [0, dp(10), 0, 0]
                IconButton:
                    source: "app/Frontend/Assets/Notificacao.png"
                    size_hint: None, None
                    size: dp(50), dp(50)
                    pos_hint: {"center_x": .5}
                    on_press: app.ir_para_notificacoes()
                Label:
                    text: "Notificações"
                    font_size: sp(12)
                    halign: "center"
                    valign: "middle"
                    text_size: self.size
                    color: 0,0,0,1
'''


# Carrega o KV
Builder.load_string(interface_TelaMapaUs)

# Classe para transformar imagem em botão
class IconButton(ButtonBehavior, Image):
    pass

# Layout principal
class TelaMapaUsuario(Screen):

    def filtrar_pontos(self): print("🔎 Filtrar")
    def pedir_ajuda(self): print("🚨 SOS")

    def ir_para_home(self):
        if self.manager: self.manager.current = "TelaInicioUs"

    def ir_para_reciclar(self):
        pass  # já está nessa tela
    
    def ir_para_notificacoes(self):...

class TelaLoginApp(App):

    def build(self):
        return TelaMapaUsuario()

if __name__ == "__main__":
    TelaLoginApp().run()