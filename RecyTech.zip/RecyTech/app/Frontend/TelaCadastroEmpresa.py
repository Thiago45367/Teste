# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.metrics import dp, sp  # dp/sp = tamanhos adaptativos

from kivy.uix.popup import Popup
from kivy.uix.label import Label

#Importações dos arquivos.
from app.Backend.Controle.ControleEmp import ControleEmp

# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaCadastroEmpresa = '''
<TelaCadastroEmp>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(10)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # Painel principal
    BoxLayout:
        orientation: 'vertical'
        size_hint: None, None
        size: root.width * 0.9, self.minimum_height
        pos_hint: {"center_x": 0.5, "center_y": 0.5}
        padding: dp(12)
        spacing: dp(10)

        canvas.before:
            Color:
                rgba: 0.2, 0.2, 0.2, 1
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(6)]

        # ===== Título =====
        Label:
            text: '[b]Recy[color=00FF00]Tech[/color][/b]'
            markup: True
            font_size: sp(26)
            size_hint_y: None
            height: dp(40)
            halign: 'center'
            valign: 'middle'
            text_size: self.size

        # ===== Abas =====
        BoxLayout:
            size_hint_y: None
            height: dp(40)
            spacing: dp(8)

            ToggleButton:
                text: 'Usuário'
                group: 'tipo'
                background_normal: ''
                background_color: 0.75, 0.75, 0.75, 1
                color: 0,0,0,1
                font_size: sp(14)
                on_release:
                    app.root.current = "TelaCadastroUsuario"

            ToggleButton:
                text: 'Empresa'
                group: 'tipo'
                background_normal: ''
                background_color: 0.12, 0.45, 0.80, 1
                color: 0,0,0,1
                font_size: sp(14)

         # ===== CAMPOS =====
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(8)
            size_hint_y: None
            height: self.minimum_height

            # Email
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Email:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: email_empresa
                    hint_text: 'Digite seu Email'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: senha_empresa
                    hint_text: 'Senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Confirmar Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Confirmar Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: confirmar
                    hint_text: 'Confirmar senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Nome da Empresa
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Nome da Empresa:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: nome_empresa
                    hint_text: 'Sua empresa'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Telefone da Empresa
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Telefone:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: telefone_empresa
                    hint_text: 'telefone da empresa'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)
            
            # CNPJ
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'CNPJ:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: cnpj
                    hint_text: 'CNPJ'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

        # Botão cadastrar
        Button:
            text: "CADASTRAR"
            size_hint_y: None
            height: dp(48)
            background_normal: ""
            background_color: 0, 0, 0, 0
            color: 1, 1, 1, 1
            font_size: dp(16)
            bold: True
            on_release: root.cadastrar()   # <<< AQUI CHAMA O MÉTODO
            canvas.before:
                Color:
                    rgba: 0, 0, 0, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [24]

        # Link abaixo do botão
        Button:
            text: "[u]Voltar para o login[/u]"
            markup: True
            background_normal: ""
            background_color: 0, 0, 0, 0
            color: 1, 1, 1, 1
            size_hint_y: None
            height: dp(28)
            font_size: dp(12)
            halign: "center"
            valign: "middle"
            text_size: self.size
            on_release:
                app.root.current = "TelaLogin"   # <<< AQUI VOLTA PARA A TELA DE LOGIN


'''

# Carrega a interface KV
Builder.load_string(interface_TelaCadastroEmpresa)

from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from datetime import datetime

from kivy.uix.screenmanager import Screen

class TelaCadastroEmp(Screen):

    def cadastrar(self):
        email_empresa = self.ids.email_empresa.text.strip()
        senha_empresa = self.ids.senha_empresa.text.strip()
        confirmar = self.ids.confirmar.text.strip()
        nome_empresa = self.ids.nome_empresa.text.strip()
        telefone_empresa = self.ids.telefone_empresa.text.strip()
        cnpj = self.ids.cnpj.text.strip()

        def mostrar_alerta(mensagem):
            label = Label(
                text=mensagem,
                halign="center",
                valign="middle"
            )
            label.bind(width=lambda *x: label.setter("text_size")(label, (label.width, None)))

            box = BoxLayout(orientation="vertical", spacing=10, padding=10)
            box.add_widget(label)

            btn_fechar = Button(text="OK", size_hint=(1, 0.3))
            box.add_widget(btn_fechar)

            popup = Popup(
                title="Atenção",
                content=box,
                size_hint=(0.9, 0.4),
                auto_dismiss=False
            )
            btn_fechar.bind(on_release=popup.dismiss)
            popup.open()

        # ---------------- VALIDAÇÕES ----------------
        if not email_empresa:
            mostrar_alerta(" Preencha o campo de E-mail!")
            return
        if not senha_empresa:
            mostrar_alerta(" Preencha o campo da Senha!")
            return
        if not confirmar:
            mostrar_alerta(" Confirme sua Senha!")
            return
        if not nome_empresa:
            mostrar_alerta(" Preencha o Nome da empresa!")
            return
        if not telefone_empresa:
            mostrar_alerta(" Preencha o Telefone!")
            return
        if not cnpj:
            mostrar_alerta(" Preencha o CNPJ!")
            return

        controle = ControleEmp()

        if controle.existe_email_empresa(email_empresa):
            mostrar_alerta(" Email já cadastrado!")
            return

        if controle.existe_cnpj(cnpj):
            mostrar_alerta(" CNPJ já cadastrado!")
            return

        if senha_empresa != confirmar:
            mostrar_alerta(" Senhas não coincidem!")
            return

        # ---------------- CADASTRO ----------------
        resultado = controle.cadastrar_empresa(
            cnpj,
            nome_empresa,
            email_empresa,
            senha_empresa,
            telefone_empresa
        )

        if resultado["sucesso"]:
            app = App.get_running_app()
            empresa_info = controle.buscar_empresa_por_email(email_empresa)

            nome_empresa_exibicao = "sua empresa"
            if empresa_info and empresa_info.get("sucesso"):
                dados = empresa_info.get("dados", {})
                app.empresa_logado = dados
                app.empresa_nome = dados.get("nome_Empresa", "")
                app.empresa_foto = dados.get("foto", "app/Frontend/Assets/Foto_Perfil.png")

                nome_empresa_exibicao = dados.get("nome_Empresa", "sua empresa")

            mostrar_alerta(f" Bem-vindo(a) à RecyTech, {nome_empresa_exibicao}!")

            # limpa os campos
            self.ids.email_empresa.text = ""
            self.ids.senha_empresa.text = ""
            self.ids.confirmar.text = ""
            self.ids.nome_empresa.text = ""
            self.ids.telefone_empresa.text = ""
            self.ids.cnpj.text = ""

            # muda para a tela inicial da empresa
            self.manager.current = "TelaInicioEmp"

        else:
            mostrar_alerta(f" Erro: {resultado['mensagem']}")

