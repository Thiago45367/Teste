# tela_cadastro.py
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
from kivy.metrics import dp, sp  # dp/sp = tamanhos adaptativos

from kivy.uix.popup import Popup
from kivy.uix.label import Label

#Importações dos arquivos.
from app.Backend.Controle.ControleUs import ControleUsu

# KV em string para evitar criar mais arquivos; mantém a interface separada do main
interface_TelaCadastroUsuario = '''
<TelaCadastroUs>:
    orientation: 'vertical'
    padding: dp(12)
    spacing: dp(10)

    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    # Painel principal
    BoxLayout:
        orientation: 'vertical'
        size_hint: None, None
        size: root.width * 0.9, self.minimum_height
        pos_hint: {"center_x": 0.5, "center_y": 0.5}
        padding: dp(12)
        spacing: dp(10)

        canvas.before:
            Color:
                rgba: 0.2, 0.2, 0.2, 1
            RoundedRectangle:
                pos: self.pos
                size: self.size
                radius: [dp(6)]

        # ===== Título =====
        Label:
            text: '[b]Recy[color=00FF00]Tech[/color][/b]'
            markup: True
            font_size: sp(26)
            size_hint_y: None
            height: dp(40)
            halign: 'center'
            valign: 'middle'
            text_size: self.size

        # ===== Abas =====
        BoxLayout:
            size_hint_y: None
            height: dp(40)
            spacing: dp(8)

            ToggleButton:
                text: 'Usuário'
                group: 'tipo'
                state: 'down'
                background_normal: ''
                background_color: 0.12, 0.45, 0.80, 1
                color: 0,0,0,1
                font_size: sp(14)

            ToggleButton:
                text: 'Empresa'
                group: 'tipo'
                background_normal: ''
                background_color: 0.75, 0.75, 0.75, 1
                color: 0,0,0,1
                font_size: sp(14)
                on_release:
                    app.root.current = "TelaCadastroEmpresa"

         # ===== CAMPOS =====
        BoxLayout:
            orientation: 'vertical'
            spacing: dp(8)
            size_hint_y: None
            height: self.minimum_height

            # Email
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Email:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: email_usuario
                    hint_text: 'Digite seu Email'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: senha_usuario
                    hint_text: 'Senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Confirmar Senha
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Confirmar Senha:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: confirmar
                    hint_text: 'Confirmar senha'
                    password: True
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Nome de Usuário
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Nome de Usuário:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: nome_usuario
                    hint_text: 'Seu usuário'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

            # Data de Nascimento
            BoxLayout:
                orientation: 'vertical'
                size_hint_y: None
                height: dp(60)
                Label:
                    text: 'Data de Nascimento:'
                    color: 1,1,1,1
                    size_hint_y: None
                    height: dp(16)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                TextInput:
                    id: data_nascimento
                    hint_text: 'DD/MM/AAAA'
                    multiline: False
                    size_hint_y: None
                    height: dp(36)

        # Botão cadastrar
        Button:
            text: "CADASTRAR"
            size_hint_y: None
            height: dp(48)
            background_normal: ""
            background_color: 0, 0, 0, 0
            color: 1, 1, 1, 1
            font_size: dp(16)
            bold: True
            on_release: root.cadastrar()   # <<< AQUI CHAMA O MÉTODO
            canvas.before:
                Color:
                    rgba: 0, 0, 0, 1
                RoundedRectangle:
                    pos: self.pos
                    size: self.size
                    radius: [24]

       # Link abaixo do botão
        Button:
            text: "[u]Voltar para o login[/u]"
            markup: True
            background_normal: ""
            background_color: 0, 0, 0, 0
            color: 1, 1, 1, 1
            size_hint_y: None
            height: dp(28)
            font_size: dp(12)
            halign: "center"
            valign: "middle"
            text_size: self.size
            on_release:
                app.root.current = "TelaLogin"   # <<< AQUI VOLTA PARA A TELA DE LOGIN


'''

# Carrega a interface KV
Builder.load_string(interface_TelaCadastroUsuario)

from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from datetime import datetime

from kivy.uix.screenmanager import Screen

class TelaCadastroUs(Screen):

    def cadastrar(self):
        email_usuario = self.ids.email_usuario.text
        senha_usuario = self.ids.senha_usuario.text
        confirmar = self.ids.confirmar.text
        nome_usuario = self.ids.nome_usuario.text
        data_nascimento = self.ids.data_nascimento.text

        def mostrar_alerta(mensagem):
            # Label configurado para quebrar linha
            label = Label(
                text=mensagem,
                halign="center",
                valign="middle"
            )
            label.bind(
                width=lambda *x: label.setter("text_size")(label, (label.width, None))
            )

            # Layout com Label + Botão OK
            box = BoxLayout(orientation="vertical", spacing=10, padding=10)
            box.add_widget(label)

            btn_fechar = Button(text="OK", size_hint=(1, 0.3))
            box.add_widget(btn_fechar)

            popup = Popup(
                title="Atenção",
                content=box,
                size_hint=(0.9, 0.4),   # ocupa 90% da largura, 40% da altura
                auto_dismiss=False
            )

            btn_fechar.bind(on_release=popup.dismiss)
            popup.open()

        # ---------------- VALIDAÇÕES ----------------
        if not email_usuario.strip():
            mostrar_alerta("Preencha o campo de E-mail!")
            return
        if not senha_usuario.strip():
            mostrar_alerta("Preencha o campo de Senha!")
            return
        if not confirmar.strip():
            mostrar_alerta("Confirme sua Senha!")
            return
        if not nome_usuario.strip():
            mostrar_alerta("Preencha o Nome de usuário!")
            return
        if not data_nascimento.strip():
            mostrar_alerta("Preencha a Data de Nascimento!")
            return
        
        controle = ControleUsu()

        # Verificar se já existe
        if controle.dao.existe_email_usuario(email_usuario):
            mostrar_alerta("Email já cadastrados")
            return
        
        if controle.dao.existe_nome_usuario(nome_usuario):
            mostrar_alerta("Nome de usuário já cadastrado!")
            return

        # --- Validação da data de nascimento ---
        from datetime import datetime

        # dentro do método cadastrar:
        try:
            data_obj = datetime.strptime(data_nascimento, "%d/%m/%Y")
            data_mysql = data_obj.strftime("%Y-%m-%d")  # formato aceito pelo MySQL
        except ValueError:
            mostrar_alerta("Digite a data de nascimento no formato DD/MM/AAAA")
            return

        if senha_usuario != confirmar:
            mostrar_alerta("Senhas não coincidem!")
            return

        # ---------------- CADASTRO ----------------
        controle = ControleUsu()
        usuario = controle.cadastrar_usuario(
            email_usuario, senha_usuario, nome_usuario, data_mysql
        )

        if usuario: # retornou dict com dados do usuário

            mostrar_alerta(f"Bem-vindo {usuario['nome']}!") # salvar usuário logado no App (sessão)
            app = App.get_running_app() 
            app.usuario_nome = usuario.get("nome", "")
            app.usuario_logado = usuario # 🔹 guarda o dict no App

             # limpar campos 
            self.ids.email_usuario.text = "" 
            self.ids.senha_usuario.text = "" 
            self.ids.confirmar.text = "" 
            self.ids.nome_usuario.text = "" 
            self.ids.data_nascimento.text = "" 
            # mudar para tela inicial 
            self.manager.current = "TelaInicioUs" 
        else: mostrar_alerta(" Erro ao cadastrar usuário. Tente novamente.")