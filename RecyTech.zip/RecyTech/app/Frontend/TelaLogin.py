from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.uix.popup import Popup
from kivy.uix.label import Label

# Imports MVC
from app.Backend.Controle.ControleLogin import ControleLogin
from app.Backend.Dao.DaoLogin import DaoLogin

# === INTERFACE KV ===
interface_TelaLogin = '''
<TelaLogin>:
    canvas.before:
        Color:
            rgba: 0.5, 0.5, 0.5, 1
        Rectangle:
            pos: self.pos
            size: self.size

    BoxLayout:
        orientation: "vertical"

        # --- CENTRO ---
        BoxLayout:
            orientation: "vertical"
            size_hint_y: 0.9
            spacing: dp(20)
            padding: [dp(30), dp(50), dp(30), dp(30)]

            Label:
                text: "[b]Recy[/b][color=00ff00]Tech[/color]"
                markup: True
                font_size: "28sp"
                size_hint_y: None
                height: dp(50)
                halign: "center"

            # --------- EMAIL ----------
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(70)

                Label:
                    text: "Email:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding_x: dp(40)

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(45)

                    Image:
                        source: "app/Frontend/Assets/Envelope.png"
                        size_hint: None, None
                        size: dp(25), dp(25)
                        pos_hint: {"center_y": 0.5}

                    TextInput:
                        id: email_input
                        hint_text: "Digite seu email"
                        multiline: False
                        size_hint_x: 1
                        font_size: "16sp"

            # --------- SENHA ----------
            BoxLayout:
                orientation: "vertical"
                size_hint_y: None
                height: dp(70)

                Label:
                    text: "Senha:"
                    size_hint_y: None
                    height: dp(20)
                    halign: "left"
                    valign: "middle"
                    text_size: self.size
                    color: (0, 0, 0, 1)
                    padding_x: dp(40)

                BoxLayout:
                    orientation: "horizontal"
                    spacing: dp(10)
                    size_hint_y: None
                    height: dp(45)
                    

                    Image:
                        source: "app/Frontend/Assets/Cadeado.png"
                        size_hint: None, None
                        size: dp(25), dp(25)
                        pos_hint: {"center_y": 0.5}

                    TextInput:
                        id: senha_input
                        hint_text: "Senha"
                        password: True
                        multiline: False
                        size_hint_x: 1
                        font_size: "16sp"

            # Botão Entrar
            AnchorLayout:
                anchor_x: "center"
                anchor_y: "center"
                size_hint_y: None
                height: dp(70)

                Button:
                    text: "ENTRAR"
                    size_hint: None, None
                    size: dp(160), dp(50)
                    background_color: (0, 0, 0, 0)
                    color: (1, 1, 1, 1)
                    canvas.before:
                        Color:
                            rgba: (0, 0, 0, 1)
                        RoundedRectangle:
                            pos: self.pos
                            size: self.size
                            radius: [25]
                    on_release: root.fazer_login()

        # --- RODAPÉ ---
        BoxLayout:
            orientation: "horizontal"
            size_hint_y: 0.1
            padding: [dp(15), dp(10)]
            spacing: dp(5)

            Label:
                text: "Não tem uma conta?"
                color: (1, 1, 1, 1)
                size_hint: None, None
                height: dp(20)
                width: self.texture_size[0]

            Button:
                text: "Cadastre-se"
                background_color: (0, 0, 0, 0)
                color: (0, 1, 0, 1)
                size_hint: None, None
                height: dp(20)
                width: self.texture_size[0]
                on_release: app.root.current = "TelaCadastroUsuario"
'''

Builder.load_string(interface_TelaLogin)

# === LÓGICA DA TELA ===
class TelaLogin(Screen):
    def fazer_login(self):
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()

        # Verificação de campos
        if not email or not senha:
            self.exibir_popup("Atenção", "Por favor, preencha todos os campos.")
            return

        controle = ControleLogin(DaoLogin())
        usuario = controle.login(email, senha)

        if usuario:
            app = App.get_running_app()
            app.usuario_logado = usuario

            self.exibir_popup("Sucesso", f"Bem-vindo {usuario['nome']}!")

            # Redireciona conforme tipo
            if usuario["tipo"] == "usuario":
                app.root.current = "TelaInicioUs"
            elif usuario["tipo"] == "empresa":
                app.empresa_nome = usuario["nome"]
                app.empresa_foto = usuario.get("foto", "")
                app.root.current = "TelaInicioEmp"
        else:
            self.exibir_popup("Erro", "Email ou senha inválidos.")

    def exibir_popup(self, titulo, mensagem):
        popup = Popup(
            title=titulo,
            content=Label(text=mensagem),
            size_hint=(0.6, 0.4)
        )
        popup.open()


# === TESTE ISOLADO ===
class TelaLoginApp(App):
    def build(self):
        self.usuario_logado = None
        self.empresa_nome = ""
        self.empresa_foto = ""
        return TelaLogin()


if __name__ == "__main__":
    TelaLoginApp().run()