-- =======================================
-- Criar schema
-- =======================================
DROP SCHEMA IF EXISTS banco_recytech;
CREATE SCHEMA banco_recytech;
USE banco_recytech;

-- =======================================
-- LOGIN (central)
-- =======================================
CREATE TABLE Login (
    id_Login INT AUTO_INCREMENT PRIMARY KEY,
    email_Login VARCHAR(50) NOT NULL UNIQUE,
    senha_Login VARCHAR(30) NOT NULL,
    tipo ENUM('usuario', 'empresa') NOT NULL
);

-- =======================================
-- USUÁRIO
-- =======================================
CREATE TABLE Usuario (
    id_Usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome_Usuario VARCHAR(50) NOT NULL,
    data_Nascimento DATE NOT NULL,
    fk_Login INT NOT NULL UNIQUE,
    FOREIGN KEY (fk_Login) REFERENCES Login(id_Login) ON DELETE CASCADE
);

-- =======================================
-- EMPRESA
-- =======================================
CREATE TABLE Empresa (
    id_Empresa INT AUTO_INCREMENT PRIMARY KEY,
    cnpj VARCHAR(30) NOT NULL UNIQUE,
    nome_Empresa VARCHAR(50) NOT NULL,
    telefone_Empresa VARCHAR(30) NOT NULL,
    fk_Login INT NOT NULL UNIQUE,
    FOREIGN KEY (fk_Login) REFERENCES Login(id_Login) ON DELETE CASCADE
);

-- =======================================
-- PONTO DE COLETA (atualizado)
-- =======================================
CREATE TABLE Ponto_Coleta (
    id_Ponto_Coleta INT AUTO_INCREMENT PRIMARY KEY,
    nome_Ponto VARCHAR(30) NOT NULL,
    cep VARCHAR(30) NOT NULL,
    numero_Endereco_Ponto VARCHAR(10) NOT NULL, -- ✅ Novo campo adicionado
    horario VARCHAR(30) NOT NULL,
    tipo_Coleta VARCHAR(50) NOT NULL,
    remuneracao VARCHAR(30) NOT NULL,
    latitude DECIMAL(10,8) NOT NULL,
    longitude DECIMAL(11,8) NOT NULL,
    fk_Empresa INT NOT NULL,
    FOREIGN KEY (fk_Empresa) REFERENCES Empresa(id_Empresa) ON DELETE CASCADE
);

-- =======================================
-- NOTIFICAÇÕES
-- =======================================
CREATE TABLE Notificacao_Usu (
    id_Notificacao_Us INT AUTO_INCREMENT PRIMARY KEY,
    data_Envio DATE NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    fk_Empresa INT NOT NULL,
    fk_Usuario INT NOT NULL,
    FOREIGN KEY (fk_Empresa) REFERENCES Empresa(id_Empresa) ON DELETE CASCADE,
    FOREIGN KEY (fk_Usuario) REFERENCES Usuario(id_Usuario) ON DELETE CASCADE
);

CREATE TABLE Notificacao_Emp (
    id_Notificacao_Emp INT AUTO_INCREMENT PRIMARY KEY,
    data_Envio DATE NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    fk_Empresa INT NOT NULL,
    FOREIGN KEY (fk_Empresa) REFERENCES Empresa(id_Empresa) ON DELETE CASCADE
);

-- =======================================
-- POSTAGENS
-- =======================================
CREATE TABLE Postagens (
    id_Post INT AUTO_INCREMENT PRIMARY KEY,
    conteudo_Post TEXT NOT NULL,
    data_Post DATETIME NOT NULL,
    tipo ENUM('usuario', 'empresa') NOT NULL,
    fk_Usuario INT NULL,
    fk_Empresa INT NULL,
    FOREIGN KEY (fk_Usuario) REFERENCES Usuario(id_Usuario) ON DELETE CASCADE,
    FOREIGN KEY (fk_Empresa) REFERENCES Empresa(id_Empresa) ON DELETE CASCADE
);

-- =======================================
-- COMENTÁRIOS
-- =======================================
CREATE TABLE Comentarios (
    id_Comentario INT AUTO_INCREMENT PRIMARY KEY,
    conteudo TEXT NOT NULL,
    data_Comentario DATETIME NOT NULL,
    fk_Post INT NOT NULL,
    fk_Usuario INT NOT NULL,
    FOREIGN KEY (fk_Post) REFERENCES Postagens(id_Post) ON DELETE CASCADE,
    FOREIGN KEY (fk_Usuario) REFERENCES Usuario(id_Usuario) ON DELETE CASCADE
);

-- =======================================
-- CURTIDAS
-- =======================================
CREATE TABLE Curtidas (
    id_Curtida INT AUTO_INCREMENT PRIMARY KEY,
    fk_Post INT NOT NULL,
    fk_Usuario INT NOT NULL,
    FOREIGN KEY (fk_Post) REFERENCES Postagens(id_Post) ON DELETE CASCADE,
    FOREIGN KEY (fk_Usuario) REFERENCES Usuario(id_Usuario) ON DELETE CASCADE
);